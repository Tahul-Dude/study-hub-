-- Fix security issues identified in the security scan

-- 1. Fix profiles table: Add additional security layer to prevent email exposure
-- Create a security definer function to control profile access more strictly
CREATE OR REPLACE FUNCTION public.get_current_user_profile()
RETURNS TABLE(
  id uuid,
  user_id uuid, 
  full_name text,
  created_at timestamp with time zone,
  updated_at timestamp with time zone,
  role text
) 
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT id, user_id, full_name, created_at, updated_at, role
  FROM public.profiles 
  WHERE user_id = auth.uid();
$$;

-- 2. Fix books table: Restrict public access to authenticated users only
DROP POLICY IF EXISTS "Users can view all books" ON public.books;
CREATE POLICY "Authenticated users can view all books" 
ON public.books 
FOR SELECT 
USING (auth.role() = 'authenticated');

-- 3. Fix quizzes table: Restrict public access to authenticated users only  
DROP POLICY IF EXISTS "Users can view all quizzes" ON public.quizzes;
CREATE POLICY "Authenticated users can view all quizzes" 
ON public.quizzes 
FOR SELECT 
USING (auth.role() = 'authenticated');

-- 4. Add additional security constraint to profiles table
-- Ensure email field cannot be selected by other users even if RLS is bypassed
ALTER TABLE public.profiles 
ADD CONSTRAINT check_email_access 
CHECK (email IS NULL OR user_id = auth.uid());

-- Comment explaining the security measures
COMMENT ON FUNCTION public.get_current_user_profile() IS 'Security function to safely return current user profile without exposing email to potential policy bypasses';
COMMENT ON CONSTRAINT check_email_access ON public.profiles IS 'Additional security layer to prevent email exposure even if RLS policies are bypassed';