// Supabase client removed to avoid duplicate instances.
// This module now only exports data models and mock data.


// Database schema types
export interface Book {
  id: string
  title: string
  author: string
  description: string
  category: string
  content?: string
  pdf_url?: string
  purchase_url?: string
  pages: number
  created_at: string
  updated_at: string
}

export interface Quiz {
  id: string
  title: string
  description: string
  category: string
  difficulty: 'Easy' | 'Medium' | 'Hard'
  questions: QuizQuestion[]
  duration: number
  created_at: string
  updated_at: string
}

export interface QuizQuestion {
  id: string
  question: string
  options: string[]
  correct_answer: number
}

export interface QuizAttempt {
  id: string
  quiz_id: string
  user_id: string
  score: number
  total_questions: number
  completed_at: string
  answers: { [questionId: string]: number }
}

export interface Note {
  id: string
  title: string
  content: string
  category: string
  level?: 'Class 12' | 'Class 11' | 'Class 10' | 'Graduate' | 'In College' | 'BSc' | 'BEd' | 'Competitive Exams' | 'Government Exams'
  tags: string[]
  pdf_url?: string
  image_urls?: string[]
  created_at: string
  updated_at: string
}

// Mock data for development (replace with real Supabase calls)
export const mockData = {
  books: [
    {
      id: "1",
      title: "Advanced Calculus",
      author: "Dr. Smith",
      description: "Comprehensive guide to advanced calculus concepts",
      category: "Mathematics",
      purchase_url: "https://www.amazon.in/s?k=Advanced+Calculus",
      content: "# Advanced Calculus\n\n## Chapter 1: Limits\n\nLimits are fundamental to calculus...\n\n## Chapter 2: Derivatives\n\nDerivatives measure the rate of change..." as string,
      pages: 450,
      created_at: "2024-01-15",
      updated_at: "2024-01-15"
    },
    {
      id: "2", 
      title: "Modern Physics",
      author: "Prof. Johnson",
      description: "Exploring quantum mechanics and relativity",
      category: "Science",
      purchase_url: "https://www.amazon.in/s?k=Modern+Physics",
      content: "# Modern Physics\n\n## Quantum Mechanics\n\nQuantum mechanics is the foundation..." as string,
      pages: 380,
      created_at: "2024-01-20",
      updated_at: "2024-01-20"
    }
  ],
  
  quizzes: [
    {
      id: "1",
      title: "Calculus Fundamentals",
      description: "Test your understanding of basic calculus concepts",
      category: "Mathematics",
      difficulty: "Medium" as const,
      duration: 30,
      questions: [
        {
          id: "1",
          question: "What is the derivative of x²?",
          options: ["2x", "x", "2", "x²"],
          correct_answer: 0
        },
        {
          id: "2",
          question: "What is the integral of 2x?",
          options: ["x²", "x² + C", "2", "2x"],
          correct_answer: 1
        },
        {
          id: "3",
          question: "What is the limit of (x² - 1)/(x - 1) as x approaches 1?",
          options: ["0", "1", "2", "undefined"],
          correct_answer: 2
        }
      ],
      created_at: "2024-01-15",
      updated_at: "2024-01-15"
    }
  ],
  
  notes: [
    {
      id: "1",
      title: "Calculus Derivatives",
      content: "# Derivative Rules\n\n## Power Rule\nd/dx[x^n] = nx^(n-1)\n\n## Product Rule\nd/dx[uv] = u'v + uv'\n\n## Chain Rule\nd/dx[f(g(x))] = f'(g(x)) * g'(x)",
      category: "Maths",
      tags: ["calculus", "derivatives", "rules"],
      created_at: "2024-01-15",
      updated_at: "2024-01-16"
    },
    {
      id: "2",
      title: "Newton's Laws of Motion",
      content: "# Newton's Laws\n\n## First Law (Inertia)\nAn object at rest stays at rest and an object in motion stays in motion unless acted upon by an external force.\n\n## Second Law\nF = ma\n\n## Third Law\nFor every action, there is an equal and opposite reaction.",
      category: "Physics",
      tags: ["mechanics", "motion", "laws"],
      created_at: "2024-01-17",
      updated_at: "2024-01-17"
    }
  ],
  
  quizAttempts: [
    {
      id: "1",
      quiz_id: "1",
      user_id: "user1",
      score: 2,
      total_questions: 3,
      completed_at: "2024-01-16",
      answers: { "1": 0, "2": 1, "3": 1 }
    }
  ]
}