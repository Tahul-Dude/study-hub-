import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Deterministic Admin ID generator derived from userId (never equals userId)
export function getAdminId(userId: string) {
  const cleaned = (userId || "").replace(/[^a-zA-Z0-9]/g, "")
  const rev = cleaned.split("").reverse().join("")
  const code = (
    cleaned.slice(0, 4) +
    rev.slice(0, 4) +
    cleaned.slice(12, 16) +
    rev.slice(8, 12)
  ).toUpperCase()
  const finalCode = `ADM-${code.slice(0, 4)}-${code.slice(4, 8)}-${code.slice(8, 12)}`
  return finalCode
}

