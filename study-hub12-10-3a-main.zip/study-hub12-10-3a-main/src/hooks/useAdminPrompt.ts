import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { getAdminId } from "@/lib/utils";
// Reusable admin gate: prompts for Admin ID and validates current admin
export function useAdminPrompt() {
  const { user, isAdmin } = useAuth();
  const { toast } = useToast();

  return (onSuccess: () => void) => {
    const entered = window.prompt(
      "Admin ID darj karein (Enter Admin ID). Hint: User menu me 'Copy Admin ID' se Admin ID copy karein."
    );
    if (!entered) return;

    if (!isAdmin) {
      toast({
        title: "Access Denied",
        description: "Sirf Admin ye action kar sakta hai.",
        variant: "destructive",
      });
      return;
    }

    if (entered.trim() !== getAdminId(user?.id || "")) {
      toast({
        title: "Galat Admin ID",
        description: "Sahi Admin ID darj karein.",
        variant: "destructive",
      });
      return;
    }

    onSuccess();
  };
}
