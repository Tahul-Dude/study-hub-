import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { useToast } from './use-toast';

interface PaymentData {
  amount: number;
  currency?: string;
  description?: string;
  customerEmail?: string;
}

export function usePayment() {
  const { session } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const createPayment = async (paymentData: PaymentData): Promise<string> => {
    if (!paymentData.amount || paymentData.amount < 50) {
      throw new Error('Amount must be at least 50 cents');
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('create-payment', {
        body: paymentData,
        headers: session ? {
          Authorization: `Bearer ${session.access_token}`,
        } : {},
      });

      if (error) throw error;
      return data.url;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Payment creation failed';
      toast({
        title: "Payment Error",
        description: message,
        variant: "destructive",
      });
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const processPayment = async (paymentData: PaymentData) => {
    try {
      const url = await createPayment(paymentData);
      // Open Stripe checkout in a new tab
      window.open(url, '_blank');
      
      toast({
        title: "Payment Processing",
        description: "Redirected to Stripe for payment. Please complete your payment in the new tab.",
      });
    } catch (error) {
      // Error already handled in createPayment
    }
  };

  return {
    createPayment,
    processPayment,
    loading,
  };
}