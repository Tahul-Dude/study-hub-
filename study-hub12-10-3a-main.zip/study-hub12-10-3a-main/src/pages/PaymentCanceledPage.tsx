import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { XCircle, ArrowLeft, CreditCard } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function PaymentCanceledPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <Card className="max-w-md w-full text-center">
        <CardHeader className="pb-6">
          <div className="mx-auto w-20 h-20 bg-destructive/10 rounded-full flex items-center justify-center mb-4">
            <XCircle className="w-10 h-10 text-destructive" />
          </div>
          <CardTitle className="text-2xl font-bold">
            Payment Canceled
          </CardTitle>
          <CardDescription>
            Your payment was canceled and no charges were made
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="bg-muted/50 rounded-lg p-4">
            <h3 className="font-semibold mb-2">What happened?</h3>
            <ul className="text-sm space-y-1 text-left text-muted-foreground">
              <li>• Payment process was interrupted</li>
              <li>• No charges were made to your account</li>
              <li>• You can try again anytime</li>
            </ul>
          </div>

          <div className="space-y-3">
            <Button 
              onClick={() => navigate('/payment')} 
              className="w-full"
            >
              <CreditCard className="w-4 h-4 mr-2" />
              Try Payment Again
            </Button>
            
            <Button 
              variant="outline" 
              onClick={() => navigate('/')}
              className="w-full"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Return Home
            </Button>
          </div>

          <p className="text-xs text-muted-foreground">
            Having trouble? Contact our support team for help with your payment.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}