import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Brain, Plus, Search, ArrowLeft, Calendar, Clock, Target, Trophy, Trash } from "lucide-react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { mockData, Quiz } from "@/lib/supabase";
import { useAdminPrompt } from "@/hooks/useAdminPrompt";


export default function QuizPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedLevel, setSelectedLevel] = useState("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState("all");
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const requireAdmin = useAdminPrompt();
  const [quizzes, setQuizzes] = useLocalStorage<Quiz[]>('study-hub-quizzes', mockData.quizzes);
  const [newQuiz, setNewQuiz] = useState({
    title: "",
    description: "",
    category: "",
    difficulty: "",
    questions: "",
    duration: ""
  });

  const categories = ["Maths", "Physics", "Chemistry", "Hindi", "English", "Arts", "Biology", "Botany", "Science", "Zoology", "Reasoning", "GK", "History", "Geography", "Currents", "Computer"];
  const difficulties = ["Easy", "Medium", "Hard"];
  const levels = ["Class 12", "Class 11", "Class 10", "Graduate", "In College", "BSc", "BEd", "Competitive Exams", "Government Exams"];

  const filteredQuizzes = quizzes.filter(quiz => {
    const matchesSearch = quiz.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         quiz.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || quiz.category === selectedCategory;
    const matchesDifficulty = selectedDifficulty === "all" || quiz.difficulty === selectedDifficulty;
    return matchesSearch && matchesCategory && matchesDifficulty;
  });

  const handleCreateQuiz = () => {
    if (!newQuiz.title || !newQuiz.category || !newQuiz.difficulty || !newQuiz.questions || !newQuiz.duration) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }
    
    const quiz: Quiz = {
      id: Date.now().toString(),
      title: newQuiz.title,
      description: newQuiz.description,
      category: newQuiz.category,
      difficulty: newQuiz.difficulty as "Easy" | "Medium" | "Hard",
      questions: [
        {
          id: "1",
          question: "Sample question - edit this quiz to add your questions",
          options: ["Option A", "Option B", "Option C", "Option D"],
          correct_answer: 0
        }
      ],
      duration: parseInt(newQuiz.duration),
      created_at: new Date().toISOString().split('T')[0],
      updated_at: new Date().toISOString().split('T')[0]
    };
    
    setQuizzes([...quizzes, quiz]);
    toast({
      title: "Success",
      description: "Quiz created successfully!"
    });
    setIsCreateOpen(false);
    setNewQuiz({ title: "", description: "", category: "", difficulty: "", questions: "", duration: "" });
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy": return "bg-study-green";
      case "Medium": return "bg-study-orange";
      case "Hard": return "bg-study-purple";
      default: return "bg-gray-500";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-accent text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Link to="/home">
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <Brain className="w-8 h-8" />
              <div>
                <h1 className="text-2xl font-bold">Quiz Center</h1>
                <p className="text-white/80 text-sm">Test your knowledge with interactive quizzes</p>
              </div>
            </div>
            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
              <Button variant="secondary" className="bg-white text-study-purple hover:bg-white/90" onClick={() => requireAdmin(() => setIsCreateOpen(true))}>
                <Plus className="w-4 h-4 mr-2" />
                Create Quiz
              </Button>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Quiz</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title">Quiz Title</Label>
                    <Input
                      id="title"
                      value={newQuiz.title}
                      onChange={(e) => setNewQuiz({ ...newQuiz, title: e.target.value })}
                      placeholder="Enter quiz title"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="category">Category</Label>
                      <Select value={newQuiz.category} onValueChange={(value) => setNewQuiz({ ...newQuiz, category: value })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category} value={category}>
                              {category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="difficulty">Difficulty</Label>
                      <Select value={newQuiz.difficulty} onValueChange={(value) => setNewQuiz({ ...newQuiz, difficulty: value })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select difficulty" />
                        </SelectTrigger>
                        <SelectContent>
                          {difficulties.map((difficulty) => (
                            <SelectItem key={difficulty} value={difficulty}>
                              {difficulty}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="questions">Number of Questions</Label>
                      <Input
                        id="questions"
                        type="number"
                        value={newQuiz.questions}
                        onChange={(e) => setNewQuiz({ ...newQuiz, questions: e.target.value })}
                        placeholder="e.g. 10"
                      />
                    </div>
                    <div>
                      <Label htmlFor="duration">Duration (minutes)</Label>
                      <Input
                        id="duration"
                        type="number"
                        value={newQuiz.duration}
                        onChange={(e) => setNewQuiz({ ...newQuiz, duration: e.target.value })}
                        placeholder="e.g. 30"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={newQuiz.description}
                      onChange={(e) => setNewQuiz({ ...newQuiz, description: e.target.value })}
                      placeholder="Enter quiz description"
                      rows={3}
                    />
                  </div>
                  <Button onClick={handleCreateQuiz} className="w-full">
                    Create Quiz
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search quizzes by title or description..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedCategory !== "all" && (
              <Select value={selectedLevel} onValueChange={setSelectedLevel}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Levels" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  {levels.map((lvl) => (
                    <SelectItem key={lvl} value={lvl}>
                      {lvl}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="All Difficulties" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Difficulties</SelectItem>
                {difficulties.map((difficulty) => (
                  <SelectItem key={difficulty} value={difficulty}>
                    {difficulty}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Categories Tabs */}
        <Tabs defaultValue="all" className="mb-6">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="all" className="data-[state=active]:bg-secondary data-[state=active]:text-secondary-foreground">
              All
            </TabsTrigger>
            {categories.map((category) => (
              <TabsTrigger
                key={category}
                value={category.toLowerCase()}
                className="data-[state=active]:bg-secondary data-[state=active]:text-secondary-foreground"
              >
                {category}
              </TabsTrigger>
            ))}
          </TabsList>
          
          <TabsContent value="all" className="mt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredQuizzes.map((quiz) => (
                <Card key={quiz.id} className="hover:shadow-medium transition-shadow duration-300">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{quiz.title}</CardTitle>
                      <div className="flex gap-2">
                        <Badge variant="secondary">{quiz.category}</Badge>
                        <Badge className={`text-white ${getDifficultyColor(quiz.difficulty)}`}>
                          {quiz.difficulty}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">{quiz.description}</p>
                    
                    <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                      <div className="flex items-center">
                        <Target className="w-4 h-4 mr-2 text-study-blue" />
                        {quiz.questions.length} Questions
                      </div>
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-2 text-study-green" />
                        {quiz.duration} mins
                      </div>
                      <div className="flex items-center">
                        <Trophy className="w-4 h-4 mr-2 text-study-orange" />
                        New Quiz
                      </div>
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-2 text-study-purple" />
                        Not taken
                      </div>
                    </div>
                    
                      <div className="text-xs text-muted-foreground mb-4">
                        Created: {new Date(quiz.created_at).toLocaleDateString()}
                      </div>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <Button 
                        className="w-full" 
                        variant="default"
                        onClick={() => navigate(`/quiz/${quiz.id}/detail`)}
                      >
                        Start Quiz
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button className="w-full" variant="destructive">
                            <Trash className="w-4 h-4 mr-2" /> Delete
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete this quiz?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This action cannot be undone. The quiz will be removed from your list.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => requireAdmin(() => { setQuizzes(prev => prev.filter(q => q.id !== quiz.id)); toast({ title: "Deleted", description: "Quiz deleted successfully" }); })}>
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          {categories.map((category) => (
            <TabsContent key={category} value={category.toLowerCase()} className="mt-6">
              <div className="mb-4 flex flex-wrap gap-2">
                <Button variant={selectedLevel === "all" ? "secondary" : "outline"} onClick={() => setSelectedLevel("all")}>
                  All Levels
                </Button>
                {levels.map((lvl) => (
                  <Button key={lvl} variant={selectedLevel === lvl ? "secondary" : "outline"} onClick={() => setSelectedLevel(lvl)}>
                    {lvl}
                  </Button>
                ))}
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {quizzes.filter(quiz => quiz.category === category).map((quiz) => (
                  <Card key={quiz.id} className="hover:shadow-medium transition-shadow duration-300">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{quiz.title}</CardTitle>
                        <Badge className={`text-white ${getDifficultyColor(quiz.difficulty)}`}>
                          {quiz.difficulty}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4">{quiz.description}</p>
                      
                      <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                      <div className="flex items-center">
                        <Target className="w-4 h-4 mr-2 text-study-blue" />
                        {quiz.questions.length} Questions
                      </div>
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-2 text-study-green" />
                          {quiz.duration} mins
                        </div>
                      <div className="flex items-center">
                        <Trophy className="w-4 h-4 mr-2 text-study-orange" />
                        New Quiz
                      </div>
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-2 text-study-purple" />
                        Not taken
                      </div>
                      </div>
                      
                      <div className="text-xs text-muted-foreground mb-4">
                        Created: {new Date(quiz.created_at).toLocaleDateString()}
                      </div>
                      
                       <div className="grid grid-cols-2 gap-2">
                         <Button 
                           className="w-full" 
                           variant="default"
                           onClick={() => navigate(`/quiz/${quiz.id}/detail`)}
                         >
                           Start Quiz
                         </Button>
                         <AlertDialog>
                           <AlertDialogTrigger asChild>
                             <Button className="w-full" variant="destructive">
                               <Trash className="w-4 h-4 mr-2" /> Delete
                             </Button>
                           </AlertDialogTrigger>
                           <AlertDialogContent>
                             <AlertDialogHeader>
                               <AlertDialogTitle>Delete this quiz?</AlertDialogTitle>
                               <AlertDialogDescription>
                                 This action cannot be undone. The quiz will be removed from your list.
                               </AlertDialogDescription>
                             </AlertDialogHeader>
                             <AlertDialogFooter>
                               <AlertDialogCancel>Cancel</AlertDialogCancel>
                               <AlertDialogAction onClick={() => requireAdmin(() => { setQuizzes(prev => prev.filter(q => q.id !== quiz.id)); toast({ title: "Deleted", description: "Quiz deleted successfully" }); })}>
                                 Delete
                               </AlertDialogAction>
                             </AlertDialogFooter>
                           </AlertDialogContent>
                         </AlertDialog>
                       </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
}