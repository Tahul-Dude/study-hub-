import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Calendar, Tag, Edit } from "lucide-react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { mockData, Note } from "@/lib/supabase";
import { useAdminPrompt } from "@/hooks/useAdminPrompt";
import { supabase } from "@/integrations/supabase/client";
import { useState, useEffect } from "react";

export default function NoteViewPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [notes] = useLocalStorage<Note[]>('study-hub-notes', mockData.notes);
  const requireAdmin = useAdminPrompt();
  
  // First try to find note in localStorage
  let note = notes.find(n => n.id === id);
  
  // If not found in localStorage, try to fetch from Supabase
  const [supabaseNote, setSupabaseNote] = useState<Note | null>(null);
  const [loading, setLoading] = useState(!note);
  
  useEffect(() => {
    if (!note && id) {
      // Try to fetch from Supabase
      const fetchNote = async () => {
        try {
          const { data, error } = await supabase
            .from('notes')
            .select('*')
            .eq('id', id)
            .maybeSingle();
          
          if (error) {
            console.error('Error fetching note:', error);
          } else if (data) {
            setSupabaseNote(data);
          }
        } catch (error) {
          console.error('Error fetching note:', error);
        } finally {
          setLoading(false);
        }
      };
      
      fetchNote();
    }
  }, [id, note]);
  
  // Use Supabase note if localStorage note not found
  const displayNote = note || supabaseNote;
  
  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-xl">Loading note...</h1>
        </div>
      </div>
    );
  }
  
  if (!displayNote) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Note not found</h1>
          <p className="text-muted-foreground mb-4">
            The note with ID "{id}" could not be found in your saved notes.
          </p>
          <Button onClick={() => navigate('/notes')}>Back to Notes</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-secondary text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Link to="/notes">
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold">{displayNote.title}</h1>
                <p className="text-white/80 text-sm">Study Note</p>
              </div>
            </div>
            <Button 
              variant="secondary" 
              className="bg-white text-study-green hover:bg-white/90"
              onClick={() => requireAdmin(() => navigate(`/notes/${displayNote.id}/edit`))}
            >
              <Edit className="w-4 h-4 mr-2" />
              Edit Note
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-6">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-start mb-4">
              <CardTitle className="text-2xl">{displayNote.title}</CardTitle>
              <Badge variant="secondary">{displayNote.category}</Badge>
            </div>
            <div className="flex flex-wrap gap-2 mb-4">
              {(displayNote.tags || []).map((tag) => (
                <Badge key={tag} variant="outline">
                  <Tag className="w-3 h-3 mr-1" />
                  {tag}
                </Badge>
              ))}
            </div>
            <div className="flex items-center text-sm text-muted-foreground">
              <Calendar className="w-4 h-4 mr-1" />
              Created: {new Date(displayNote.created_at).toLocaleDateString()}
              {displayNote.updated_at !== displayNote.created_at && (
                <span className="ml-4">
                  Updated: {new Date(displayNote.updated_at).toLocaleDateString()}
                </span>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {displayNote.pdf_url ? (
              <div className="space-y-4">
                {displayNote.pdf_url.includes('onedrive.live.com') || 
                 displayNote.pdf_url.includes('sharepoint.com') ||
                 displayNote.pdf_url.includes('drive.google.com') ? (
                  <div className="rounded-md border bg-muted/10 p-8 text-center space-y-4">
                    <div className="text-lg font-medium">External Document Link</div>
                    <p className="text-muted-foreground">
                      This note links to an external document that cannot be embedded for security reasons.
                    </p>
                    <Button asChild>
                      <a href={displayNote.pdf_url} target="_blank" rel="noopener noreferrer">
                        Open Document in New Tab
                      </a>
                    </Button>
                  </div>
                ) : (
                  <div className="rounded-md overflow-hidden border bg-muted/10">
                    <iframe
                      src={`${displayNote.pdf_url}#toolbar=1`}
                      title={`${displayNote.title} PDF`}
                      className="w-full h-[75vh]"
                      loading="lazy"
                      onError={() => {
                        console.error('PDF iframe failed to load:', displayNote.pdf_url);
                      }}
                    />
                  </div>
                )}
                <div className="text-sm text-muted-foreground">
                  Having trouble viewing the document? 
                  <a href={displayNote.pdf_url} target="_blank" rel="noopener noreferrer" className="underline ml-1 text-primary hover:text-primary/90">Open in a new tab</a>.
                </div>
              </div>
            ) : (
              <div className="prose prose-slate max-w-none">
                <pre className="whitespace-pre-wrap font-sans">{displayNote.content || 'No content available for this note.'}</pre>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}