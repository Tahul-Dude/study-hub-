import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, Home, Receipt } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';

export default function PaymentSuccessPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get('session_id');
  const [verifying, setVerifying] = useState(true);

  useEffect(() => {
    // Simulate verification process
    const timer = setTimeout(() => {
      setVerifying(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <Card className="max-w-md w-full text-center">
        <CardHeader className="pb-6">
          <div className="mx-auto w-20 h-20 bg-success/10 rounded-full flex items-center justify-center mb-4">
            <CheckCircle className="w-10 h-10 text-success" />
          </div>
          <CardTitle className="text-2xl font-bold">
            Payment Successful!
          </CardTitle>
          <CardDescription>
            {verifying 
              ? "Verifying your payment..." 
              : "Your payment has been processed successfully"
            }
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {sessionId && (
            <div className="bg-muted/50 rounded-lg p-4">
              <p className="text-sm text-muted-foreground mb-1">Transaction ID</p>
              <p className="text-xs font-mono break-all">{sessionId}</p>
            </div>
          )}

          <div className="bg-success/5 rounded-lg p-4">
            <h3 className="font-semibold mb-2">What's next?</h3>
            <ul className="text-sm space-y-1 text-left">
              <li>• A receipt has been sent to your email</li>
              <li>• Your payment is being processed</li>
              <li>• You'll receive confirmation shortly</li>
            </ul>
          </div>

          <div className="space-y-3">
            <Button 
              onClick={() => navigate('/')} 
              className="w-full"
            >
              <Home className="w-4 h-4 mr-2" />
              Return Home
            </Button>
            
            <Button 
              variant="outline" 
              onClick={() => window.print()}
              className="w-full"
            >
              <Receipt className="w-4 h-4 mr-2" />
              Print Receipt
            </Button>
          </div>

          <p className="text-xs text-muted-foreground">
            Need help? Contact our support team for assistance.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}