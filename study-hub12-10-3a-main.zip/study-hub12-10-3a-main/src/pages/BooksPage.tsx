import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BookOpen, Plus, Search, ArrowLeft, Calendar, User, ShoppingCart, Trash } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { mockData, Book, Note, Quiz } from "@/lib/supabase";
import { useAuth } from "@/hooks/useAuth";
import { useAdminPrompt } from "@/hooks/useAdminPrompt";
import { supabase } from "@/integrations/supabase/client";
import { getAdminId } from "@/lib/utils";
export default function BooksPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user, isAdmin } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedLevel, setSelectedLevel] = useState("all");
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const requireAdmin = useAdminPrompt();
  const [books, setBooks] = useLocalStorage<Book[]>('study-hub-books', mockData.books);
  const [notes] = useLocalStorage<Note[]>('study-hub-notes', mockData.notes);
  const [quizzes] = useLocalStorage<Quiz[]>('study-hub-quizzes', mockData.quizzes);
  const [newBook, setNewBook] = useState({
    title: "",
    author: "",
    description: "",
    category: "",
    pages: "",
    purchase_url: ""
  });
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  // Seed sample books if none exist
  useEffect(() => {
    if (!books || books.length === 0) {
      setBooks(mockData.books);
    }
  }, [books, setBooks]);

  const handleAdminEdit = (bookId: string) => {
    const entered = window.prompt("Admin ID darj karein (Enter Admin ID) :");
    if (!entered) return;
    if (!isAdmin) {
      toast({ title: "Access Denied", description: "Sirf Admin edit kar sakta hai.", variant: "destructive" });
      return;
    }
    if (entered.trim() !== getAdminId(user?.id || "")) {
      toast({ title: "Galat Admin ID", description: "Sahi Admin ID darj karein.", variant: "destructive" });
      return;
    }
    navigate(`/books/${bookId}/edit`);
  };

  const categories = ["Mathematics", "Maths", "Science", "Physics", "Biology", "Chemistry", "Hindi", "English", "History", "Literature", "Technology", "Arts"];
  const levels = ["Class 12", "Class 11", "Class 10", "Graduate", "In College", "BSc", "BEd", "Competitive Exams", "Government Exams"];

  const filteredBooks = books.filter(book => {
    const matchesSearch = book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         book.author.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || book.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleCreateBook = async () => {
    if (!newBook.title || !newBook.author || !newBook.category) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    setIsUploading(true);
    let pdfUrl: string | undefined = undefined;

    try {
      if (pdfFile) {
        const filePath = `${user?.id || 'anon'}/${Date.now()}-${pdfFile.name}`;
        const { error: uploadError } = await supabase.storage
          .from('books')
          .upload(filePath, pdfFile, { contentType: 'application/pdf' });

        if (uploadError) throw uploadError;

        const { data } = supabase.storage.from('books').getPublicUrl(filePath);
        pdfUrl = data.publicUrl;
      }

      const now = new Date().toISOString();
      const { data: inserted, error: insertError } = await supabase
        .from('books')
        .insert({
          title: newBook.title,
          author: newBook.author,
          description: newBook.description || null,
          category: newBook.category,
          content: '',
          pdf_url: pdfUrl ?? null,
          pages: newBook.pages ? parseInt(newBook.pages) : null,
          created_at: now,
          updated_at: now,
          user_id: (user?.id as string),
        })
        .select()
        .single();

      if (insertError) throw insertError;

      const book: Book = {
        id: inserted.id,
        title: inserted.title,
        author: inserted.author,
        description: inserted.description ?? "",
        category: inserted.category,
        content: inserted.content ?? "",
        pdf_url: inserted.pdf_url ?? undefined,
        purchase_url: newBook.purchase_url || undefined,
        pages: inserted.pages ?? 0,
        created_at: inserted.created_at,
        updated_at: inserted.updated_at
      };

      setBooks([...books, book]);
      toast({ title: "Success", description: "Book created successfully!", variant: "success" });
      setIsCreateOpen(false);
      setNewBook({ title: "", author: "", description: "", category: "", pages: "", purchase_url: "" });
      setPdfFile(null);
    } catch (error) {
      console.error(error);
      toast({ title: "Save Failed", description: "Book save karte waqt error aaya.", variant: "destructive" });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-primary text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Link to="/home">
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <BookOpen className="w-8 h-8" />
              <div>
                <h1 className="text-2xl font-bold">Books Library</h1>
                <p className="text-white/80 text-sm">Browse and manage your study books</p>
              </div>
            </div>
            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
              <Button variant="secondary" className="bg-white text-study-blue hover:bg-white/90" onClick={() => requireAdmin(() => setIsCreateOpen(true))}>
                <Plus className="w-4 h-4 mr-2" />
                Add Book
              </Button>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Book</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title">Title</Label>
                    <Input
                      id="title"
                      value={newBook.title}
                      onChange={(e) => setNewBook({ ...newBook, title: e.target.value })}
                      placeholder="Enter book title"
                    />
                  </div>
                  <div>
                    <Label htmlFor="author">Author</Label>
                    <Input
                      id="author"
                      value={newBook.author}
                      onChange={(e) => setNewBook({ ...newBook, author: e.target.value })}
                      placeholder="Enter author name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Select value={newBook.category} onValueChange={(value) => setNewBook({ ...newBook, category: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="pages">Number of Pages</Label>
                    <Input
                      id="pages"
                      type="number"
                      value={newBook.pages}
                      onChange={(e) => setNewBook({ ...newBook, pages: e.target.value })}
                      placeholder="Enter page count"
                    />
                  </div>
                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={newBook.description}
                      onChange={(e) => setNewBook({ ...newBook, description: e.target.value })}
                      placeholder="Enter book description"
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label htmlFor="purchase_url">Amazon URL (optional)</Label>
                    <Input
                      id="purchase_url"
                      type="url"
                      value={newBook.purchase_url}
                      onChange={(e) => setNewBook({ ...newBook, purchase_url: e.target.value })}
                      placeholder="Paste Amazon link to buy this book"
                    />
                  </div>
                  <div>
                    <Label htmlFor="pdf">Attach PDF (optional)</Label>
                    <Input
                      id="pdf"
                      type="file"
                      accept="application/pdf"
                      onChange={(e) => setPdfFile(e.target.files?.[0] || null)}
                    />
                  </div>
                  <Button onClick={handleCreateBook} className="w-full" disabled={isUploading}>
                    {isUploading ? "Uploading..." : "Create Book"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="container mx-auto px-4 py-6">
        {/* Totals Summary */}
        <div className="grid grid-cols-1 gap-4 mb-6">
          <Card>
            <CardContent className="py-4 flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Books</p>
                <p className="text-2xl font-semibold">{books.length}</p>
              </div>
              <BookOpen className="w-6 h-6 text-study-blue" />
            </CardContent>
          </Card>
        </div>
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search books by title or author..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((category) => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {selectedCategory !== "all" && (
            <Select value={selectedLevel} onValueChange={setSelectedLevel}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="All Levels" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                {levels.map((lvl) => (
                  <SelectItem key={lvl} value={lvl}>
                    {lvl}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* Categories Tabs */}
        <Tabs defaultValue="all" className="mb-6">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="all">All</TabsTrigger>
            {categories.map((category) => (
              <TabsTrigger key={category} value={category.toLowerCase()}>
                {category}
              </TabsTrigger>
            ))}
          </TabsList>
          
          <TabsContent value="all" className="mt-6">
            {filteredBooks.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <p className="mb-4">No books found.</p>
                <div className="flex gap-2 justify-center">
                  <Button variant="outline" onClick={() => { setSearchTerm(""); setSelectedCategory("all"); }}>Reset Filters</Button>
                  <Button onClick={() => { setBooks(mockData.books); toast({ title: "Sample data loaded", description: "Default books restored." }); }}>Load Sample Books</Button>
                </div>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredBooks.map((book) => (
                  <Card key={book.id} className="hover:shadow-medium transition-shadow duration-300">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{book.title}</CardTitle>
                        <Badge variant="secondary">{book.category}</Badge>
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <User className="w-4 h-4 mr-1" />
                        {book.author}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4">{book.description}</p>
                      <div className="flex justify-between items-center text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {new Date(book.created_at).toLocaleDateString()}
                        </div>
                        <span>{book.pages} pages</span>
                      </div>
                      <div className="flex gap-2 mt-4">
                        <Button 
                          className="flex-1" 
                          variant="outline"
                          onClick={() => navigate(`/books/${book.id}/read`)}
                        >
                          Read Book
                        </Button>
                        <Button 
                          className="flex-1" 
                          variant="secondary"
                          onClick={() => handleAdminEdit(book.id)}
                        >
                          Edit
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button className="flex-1" variant="destructive">
                              <Trash className="w-4 h-4 mr-2" /> Delete
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete this book?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This action cannot be undone. The book will be removed from your library.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => requireAdmin(() => { setBooks(prev => prev.filter(b => b.id !== book.id)); toast({ title: "Deleted", description: "Book deleted successfully" }); })}>
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                        {book.purchase_url && (
                          <Button asChild className="w-full mt-2">
                             <a
                               href={book.purchase_url}
                               target="_blank"
                               rel="noopener noreferrer nofollow sponsored"
                               onClick={() => {
                                 try {
                                   const c = parseInt(localStorage.getItem('purchase-count') || '0', 10) + 1;
                                   localStorage.setItem('purchase-count', String(c));
                                   window.dispatchEvent(new Event('purchase-count-updated'));
                                 } catch {}
                               }}
                             >
                              <span className="inline-flex items-center">
                                <ShoppingCart className="w-4 h-4 mr-2" />
                                Buy on Amazon
                              </span>
                            </a>
                          </Button>
                        )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
          
          {categories.map((category) => (
            <TabsContent key={category} value={category.toLowerCase()} className="mt-6">
              <div className="mb-4 flex flex-wrap gap-2">
                <Button variant={selectedLevel === "all" ? "secondary" : "outline"} onClick={() => setSelectedLevel("all")}>
                  All Levels
                </Button>
                {levels.map((lvl) => (
                  <Button key={lvl} variant={selectedLevel === lvl ? "secondary" : "outline"} onClick={() => setSelectedLevel(lvl)}>
                    {lvl}
                  </Button>
                ))}
              </div>
              {books.filter(book => book.category === category).length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <p className="mb-4">No books in this category.</p>
                  <div className="flex gap-2 justify-center">
                    <Button variant="outline" onClick={() => { setSearchTerm(""); setSelectedCategory("all"); }}>View All</Button>
                    <Button onClick={() => { setBooks(mockData.books); toast({ title: "Sample data loaded", description: "Default books restored." }); }}>Load Sample Books</Button>
                  </div>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {books.filter(book => book.category === category).map((book) => (
                    <Card key={book.id} className="hover:shadow-medium transition-shadow duration-300">
                      <CardHeader>
                        <CardTitle className="text-lg">{book.title}</CardTitle>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <User className="w-4 h-4 mr-1" />
                          {book.author}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground mb-4">{book.description}</p>
                        <div className="flex justify-between items-center text-sm text-muted-foreground">
                          <div className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            {new Date(book.created_at).toLocaleDateString()}
                          </div>
                          <span>{book.pages} pages</span>
                        </div>
                          <div className="flex gap-2 mt-4">
                            <Button 
                              className="flex-1" 
                              variant="outline"
                              onClick={() => navigate(`/books/${book.id}/read`)}
                            >
                              Read Book
                            </Button>
                            <Button 
                              className="flex-1" 
                              variant="secondary"
                              onClick={() => handleAdminEdit(book.id)}
                            >
                              Edit
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button className="flex-1" variant="destructive">
                                  <Trash className="w-4 h-4 mr-2" /> Delete
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Delete this book?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    This action cannot be undone. The book will be removed from your library.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => requireAdmin(() => { setBooks(prev => prev.filter(b => b.id !== book.id)); toast({ title: "Deleted", description: "Book deleted successfully" }); })}>
                                    Delete
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                          {book.purchase_url && (
                            <Button asChild className="w-full mt-2">
                               <a
                                 href={book.purchase_url}
                                 target="_blank"
                                 rel="noopener noreferrer nofollow sponsored"
                                 onClick={() => {
                                   try {
                                     const c = parseInt(localStorage.getItem('purchase-count') || '0', 10) + 1;
                                     localStorage.setItem('purchase-count', String(c));
                                     window.dispatchEvent(new Event('purchase-count-updated'));
                                   } catch {}
                                 }}
                               >
                                <span className="inline-flex items-center">
                                  <ShoppingCart className="w-4 h-4 mr-2" />
                                  Buy on Amazon
                                </span>
                              </a>
                            </Button>
                          )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
}