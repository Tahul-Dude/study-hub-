import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, ArrowRight, Clock, CheckCircle, Target } from "lucide-react"
import { useNavigate, useParams } from "react-router-dom"
import { useState, useEffect } from "react"
import { mockData, Quiz, QuizAttempt } from "@/lib/supabase"
import { useToast } from "@/hooks/use-toast"
import { useLocalStorage } from "@/hooks/useLocalStorage"

export default function QuizTakePage() {
  const navigate = useNavigate()
  const { id } = useParams()
  const { toast } = useToast()
  
  const [quiz, setQuiz] = useState<Quiz | null>(null)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<{ [questionId: string]: number }>({})
  const [timeLeft, setTimeLeft] = useState(0)
  const [isCompleted, setIsCompleted] = useState(false)
  const [attempts, setAttempts] = useLocalStorage<QuizAttempt[]>('quiz-attempts', mockData.quizAttempts)
  const [quizzes] = useLocalStorage<Quiz[]>('study-hub-quizzes', mockData.quizzes)

  // Get user stats
  const userAttempts = attempts.filter((attempt: QuizAttempt) => attempt.quiz_id === id)
  const attemptCount = userAttempts.length
  const bestScore = userAttempts.length > 0 
    ? Math.max(...userAttempts.map((a: QuizAttempt) => Math.round((a.score / a.total_questions) * 100)))
    : 0

  useEffect(() => {
    const loadQuiz = () => {
      const foundQuiz = quizzes.find(q => q.id === id)
      if (foundQuiz) {
        setQuiz(foundQuiz)
        setTimeLeft(foundQuiz.duration * 60) // Convert to seconds
      } else {
        toast({
          title: "Quiz Not Found",
          description: "The requested quiz could not be found.",
          variant: "destructive"
        })
        navigate("/quiz")
      }
    }

    if (id) {
      loadQuiz()
    }
  }, [id, quizzes, navigate, toast])

  useEffect(() => {
    if (timeLeft > 0 && !isCompleted) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
      return () => clearTimeout(timer)
    } else if (timeLeft === 0 && quiz) {
      handleSubmit()
    }
  }, [timeLeft, isCompleted, quiz])

  const handleAnswerSelect = (answerIndex: number) => {
    if (!quiz) return
    
    setAnswers(prev => ({
      ...prev,
      [quiz.questions[currentQuestion].id]: answerIndex
    }))
  }

  const handleNext = () => {
    if (!quiz) return
    
    if (currentQuestion < quiz.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const handleSubmit = () => {
    if (!quiz) return

    const score = quiz.questions.reduce((total, question) => {
      return total + (answers[question.id] === question.correct_answer ? 1 : 0)
    }, 0)

    const attempt: QuizAttempt = {
      id: Date.now().toString(),
      quiz_id: quiz.id,
      user_id: "user1",
      score,
      total_questions: quiz.questions.length,
      completed_at: new Date().toISOString(),
      answers
    }

    setAttempts([...attempts, attempt])
    setIsCompleted(true)

    toast({
      title: "Quiz Completed!",
      description: `You scored ${score}/${quiz.questions.length} (${Math.round((score / quiz.questions.length) * 100)}%)`
    })
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const progress = quiz ? ((currentQuestion + 1) / quiz.questions.length) * 100 : 0

  if (!quiz) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p>Loading quiz...</p>
        </div>
      </div>
    )
  }

  if (isCompleted) {
    const score = quiz.questions.reduce((total, question) => {
      return total + (answers[question.id] === question.correct_answer ? 1 : 0)
    }, 0)
    const percentage = Math.round((score / quiz.questions.length) * 100)

    return (
      <div className="min-h-screen bg-background">
        <div className="bg-gradient-accent text-white">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center space-x-3">
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-white hover:bg-white/10"
                onClick={() => navigate("/quiz")}
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold">Quiz Completed</h1>
                <p className="text-white/80 text-sm">{quiz.title}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-8">
          <div className="max-w-2xl mx-auto">
            <Card>
              <CardHeader className="text-center">
                <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
                <CardTitle className="text-2xl">Great Job!</CardTitle>
              </CardHeader>
              <CardContent className="text-center space-y-6">
                <div className="grid grid-cols-3 gap-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-primary">{score}</div>
                    <div className="text-sm text-muted-foreground">Correct</div>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-primary">{percentage}%</div>
                    <div className="text-sm text-muted-foreground">Score</div>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-primary">{attemptCount + 1}</div>
                    <div className="text-sm text-muted-foreground">Attempts</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-lg">Your Score: <span className="font-bold">{score}/{quiz.questions.length}</span></p>
                  <p className="text-muted-foreground">Previous Best: {bestScore}%</p>
                  <p className="text-muted-foreground">Total Attempts: {attemptCount + 1}</p>
                </div>

                <div className="flex gap-4">
                  <Button 
                    onClick={() => navigate("/quiz")}
                    variant="outline"
                    className="flex-1"
                  >
                    Back to Quizzes
                  </Button>
                  <Button 
                    onClick={() => window.location.reload()}
                    className="flex-1"
                  >
                    Retake Quiz
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  const question = quiz.questions[currentQuestion]

  return (
    <div className="min-h-screen bg-background">
      {/* Header with Timer */}
      <div className="bg-gradient-accent text-white">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-white hover:bg-white/10"
                onClick={() => navigate("/quiz")}
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-xl font-bold">{quiz.title}</h1>
                <p className="text-white/80 text-sm">Question {currentQuestion + 1} of {quiz.questions.length}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 text-right">
              <div>
                <div className="text-sm text-white/80">Attempts: {attemptCount}</div>
                <div className="text-sm text-white/80">Best: {bestScore}%</div>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-5 h-5" />
                <span className="text-xl font-mono">{formatTime(timeLeft)}</span>
              </div>
            </div>
          </div>
          <div className="mt-4">
            <Progress value={progress} className="h-2" />
          </div>
        </div>
      </div>

      {/* Question */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <Badge variant="secondary" className="mb-2">
                    Question {currentQuestion + 1}
                  </Badge>
                  <CardTitle className="text-xl">{question.question}</CardTitle>
                </div>
                <div className="text-right text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <Target className="w-4 h-4 mr-1" />
                    {quiz.questions.length} Questions
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {question.options.map((option, index) => (
                  <Button
                    key={index}
                    variant={answers[question.id] === index ? "default" : "outline"}
                    className="w-full justify-start p-4 h-auto text-left"
                    onClick={() => handleAnswerSelect(index)}
                  >
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-full border-2 border-current flex items-center justify-center mr-3 text-sm font-bold">
                        {String.fromCharCode(65 + index)}
                      </div>
                      {option}
                    </div>
                  </Button>
                ))}
              </div>

              <div className="flex justify-between mt-8">
                <Button
                  variant="outline"
                  onClick={handlePrevious}
                  disabled={currentQuestion === 0}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Previous
                </Button>

                {currentQuestion === quiz.questions.length - 1 ? (
                  <Button
                    onClick={handleSubmit}
                    disabled={Object.keys(answers).length !== quiz.questions.length}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Submit Quiz
                  </Button>
                ) : (
                  <Button
                    onClick={handleNext}
                    disabled={answers[question.id] === undefined}
                  >
                    Next
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                )}
              </div>

              {/* Answer Status */}
              <div className="mt-4 p-4 bg-muted rounded-lg">
                <div className="flex justify-between text-sm">
                  <span>Answered: {Object.keys(answers).length}/{quiz.questions.length}</span>
                  <span>Remaining: {quiz.questions.length - Object.keys(answers).length}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}