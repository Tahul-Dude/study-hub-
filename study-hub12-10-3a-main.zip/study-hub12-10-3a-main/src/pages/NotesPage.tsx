import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Plus, Search, ArrowLeft, Calendar, Tag, Trash } from "lucide-react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { mockData, Note } from "@/lib/supabase";
import { useAdminPrompt } from "@/hooks/useAdminPrompt";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

export default function NotesPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedLevel, setSelectedLevel] = useState("all");
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const requireAdmin = useAdminPrompt();
  const [notes, setNotes] = useLocalStorage<Note[]>('study-hub-notes', mockData.notes);
  const [newNote, setNewNote] = useState({
    title: "",
    content: "",
    category: "",
    level: "",
    tags: ""
  });
  const { user } = useAuth();
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  const categories = ["Maths", "Physics", "Chemistry", "Biology", "Botany", "Science", "Hindi", "English", "Arts", "General GK", "Reasoning", "History", "Geography"];
  const levels = ["Class 12", "Class 11", "Class 10", "Graduate", "In College", "BSc", "BEd", "Competitive Exams", "Government Exams"];

  const filteredNotes = notes.filter(note => {
    const matchesSearch = note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         note.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         note.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === "all" || note.category === selectedCategory;
    const matchesLevel = selectedLevel === "all" || note.level === selectedLevel;
    return matchesSearch && matchesCategory && matchesLevel;
  });

  const handleCreateNote = async () => {
    if (!newNote.title || !newNote.content || !newNote.category) {
      alert("Please fill in all required fields");
      return;
    }

    setIsUploading(true);
    let hadUploadIssue = false;
    let pdfUrl: string | undefined = undefined;
    let imageUrls: string[] = [];
    try {
      // Upload PDF if selected
      if (pdfFile) {
        const filePath = `${user?.id || 'anon'}/notes/${Date.now()}-${pdfFile.name}`;
        const { error: uploadError } = await supabase.storage
          .from('notes')
          .upload(filePath, pdfFile, { contentType: 'application/pdf' });
        if (uploadError) {
          console.error(uploadError);
          hadUploadIssue = true;
        } else {
          const { data } = supabase.storage.from('notes').getPublicUrl(filePath);
          pdfUrl = data.publicUrl;
        }
      }

      // Upload images if selected
      if (imageFiles.length > 0) {
        const uploads = await Promise.all(imageFiles.map(async (img) => {
          const imgPath = `${user?.id || 'anon'}/notes/${Date.now()}-${img.name}`;
          const { error } = await supabase.storage
            .from('notes')
            .upload(imgPath, img, { contentType: img.type || 'image/jpeg' });
          if (error) {
            console.error(error);
            hadUploadIssue = true;
            return '';
          }
          const { data } = supabase.storage.from('notes').getPublicUrl(imgPath);
          return data.publicUrl;
        }));
        imageUrls = uploads.filter(Boolean);
      }

      const note: Note = {
        id: crypto.randomUUID(),
        title: newNote.title,
        content: newNote.content,
        category: newNote.category,
        level: (newNote.level as Note['level']) || undefined,
        tags: newNote.tags.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0),
        pdf_url: pdfUrl,
        image_urls: imageUrls,
        created_at: new Date().toISOString().split('T')[0],
        updated_at: new Date().toISOString().split('T')[0]
      };

      setNotes([...notes, note]);
      toast({
        title: "Success",
        description: "Note created successfully!",
        variant: "success"
      });
      if (hadUploadIssue) {
        toast({
          title: "Saved without files",
          description: "Storage bucket missing. Files were not uploaded."
        });
      }
      setIsCreateOpen(false);
      setNewNote({ title: "", content: "", category: "", level: "", tags: "" });
      setPdfFile(null);
      setImageFiles([]);
    } catch (error) {
      console.error(error);
      toast({ title: "Upload Failed", description: "PDF/images upload me dikkat aayi.", variant: "destructive" });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background" role="main">
      {/* Header */}
      <div className="bg-gradient-secondary text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Link to="/home">
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <FileText className="w-8 h-8" />
              <div>
                <h1 className="text-2xl font-bold">Study Notes</h1>
                <p className="text-white/80 text-sm">Organize and manage your study notes</p>
              </div>
            </div>
            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
              <Button variant="secondary" className="bg-white text-study-green hover:bg-white/90" onClick={() => requireAdmin(() => setIsCreateOpen(true))}>
                <Plus className="w-4 h-4 mr-2" />
                Add Note
              </Button>
              <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Create New Note</DialogTitle>
                    <DialogDescription>Fill details to create a note.</DialogDescription>
                  </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title">Title</Label>
                    <Input
                      id="title"
                      value={newNote.title}
                      onChange={(e) => setNewNote({ ...newNote, title: e.target.value })}
                      placeholder="Enter note title"
                    />
                  </div>
                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Select value={newNote.category} onValueChange={(value) => setNewNote({ ...newNote, category: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {newNote.category && (
                    <div>
                      <Label htmlFor="level">Level</Label>
                      <Select value={newNote.level} onValueChange={(value) => setNewNote({ ...newNote, level: value })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select level" />
                        </SelectTrigger>
                        <SelectContent>
                          {levels.map((lvl) => (
                            <SelectItem key={lvl} value={lvl}>
                              {lvl}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  <div>
                    <Label htmlFor="tags">Tags (comma separated)</Label>
                    <Input
                      id="tags"
                      value={newNote.tags}
                      onChange={(e) => setNewNote({ ...newNote, tags: e.target.value })}
                      placeholder="math, physics, important"
                    />
                  </div>
                  <div>
                    <Label htmlFor="content">Content</Label>
                    <Textarea
                      id="content"
                      value={newNote.content}
                      onChange={(e) => setNewNote({ ...newNote, content: e.target.value })}
                      placeholder="Enter your notes here..."
                      rows={8}
                    />
                  </div>
                  <div>
                    <Label htmlFor="pdf">Attach PDF (optional)</Label>
                    <Input
                      id="pdf"
                      type="file"
                      accept="application/pdf"
                      onChange={(e) => setPdfFile(e.target.files?.[0] || null)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="images">Upload Photos (optional)</Label>
                    <Input
                      id="images"
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={(e) => setImageFiles(Array.from(e.target.files || []))}
                    />
                  </div>
                  <Button onClick={handleCreateNote} className="w-full" disabled={isUploading}>
                    {isUploading ? "Uploading..." : "Create Note"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search notes by title, content, or tags..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((category) => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {selectedCategory !== "all" && (
            <Select value={selectedLevel} onValueChange={setSelectedLevel}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="All Levels" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                {levels.map((lvl) => (
                  <SelectItem key={lvl} value={lvl}>
                    {lvl}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* Categories Tabs */}
        <Tabs defaultValue="all" className="mb-6">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="all">All</TabsTrigger>
            {categories.map((category) => (
              <TabsTrigger key={category} value={category.toLowerCase().replace(/\s+/g, '-')}> 
                {category.split(' ')[0]}
              </TabsTrigger>
            ))}
          </TabsList>
          
          <TabsContent value="all" className="mt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredNotes.map((note) => (
                <Card key={note.id} className="hover:shadow-medium transition-shadow duration-300">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{note.title}</CardTitle>
                      <Badge variant="secondary">{note.category}</Badge>
                    </div>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {note.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          <Tag className="w-3 h-3 mr-1" />
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4 line-clamp-3">{note.content}</p>
                    <div className="flex justify-between items-center text-sm text-muted-foreground mb-4">
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-1" />
                        {new Date(note.created_at).toLocaleDateString()}
                      </div>
                      {note.updated_at !== note.created_at && (
                        <span>Updated: {new Date(note.updated_at).toLocaleDateString()}</span>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        className="flex-1" 
                        variant="outline"
                        onClick={() => navigate(`/notes/${note.id}/view`)}
                      >
                        View
                      </Button>
                      <Button 
                        className="flex-1" 
                        variant="secondary"
                        onClick={() => requireAdmin(() => navigate(`/notes/${note.id}/edit`))}
                      >
                        Edit
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button className="flex-1" variant="destructive">
                            <Trash className="w-4 h-4 mr-2" /> Delete
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete this note?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This action cannot be undone. The note will be removed from your notes.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => requireAdmin(() => { setNotes(prev => prev.filter(n => n.id !== note.id)); toast({ title: "Deleted", description: "Note deleted successfully" }); })}>
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          {categories.map((category) => (
            <TabsContent key={category} value={category.toLowerCase().replace(/\s+/g, '-')} className="mt-6">
              <div className="mb-4 flex flex-wrap gap-2">
                <Button variant={selectedLevel === "all" ? "secondary" : "outline"} onClick={() => setSelectedLevel("all")}>
                  All Levels
                </Button>
                {levels.map((lvl) => (
                  <Button key={lvl} variant={selectedLevel === lvl ? "secondary" : "outline"} onClick={() => setSelectedLevel(lvl)}>
                    {lvl}
                  </Button>
                ))}
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {notes.filter(note => note.category === category && (selectedLevel === "all" || note.level === selectedLevel)).map((note) => (
                  <Card key={note.id} className="hover:shadow-medium transition-shadow duration-300">
                    <CardHeader>
                      <CardTitle className="text-lg">{note.title}</CardTitle>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {note.tags.map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            <Tag className="w-3 h-3 mr-1" />
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4 line-clamp-3">{note.content}</p>
                      <div className="flex justify-between items-center text-sm text-muted-foreground mb-4">
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {new Date(note.created_at).toLocaleDateString()}
                        </div>
                        {note.updated_at !== note.created_at && (
                          <span>Updated: {new Date(note.updated_at).toLocaleDateString()}</span>
                        )}
                      </div>
                         <div className="flex gap-2">
                           <Button 
                             className="flex-1" 
                             variant="outline"
                             onClick={() => navigate(`/notes/${note.id}/view`)}
                           >
                             View
                           </Button>
                           <Button 
                             className="flex-1" 
                             variant="secondary"
                             onClick={() => requireAdmin(() => navigate(`/notes/${note.id}/edit`))}
                           >
                             Edit
                           </Button>
                           <AlertDialog>
                             <AlertDialogTrigger asChild>
                               <Button className="flex-1" variant="destructive">
                                 <Trash className="w-4 h-4 mr-2" /> Delete
                               </Button>
                             </AlertDialogTrigger>
                             <AlertDialogContent>
                               <AlertDialogHeader>
                                 <AlertDialogTitle>Delete this note?</AlertDialogTitle>
                                 <AlertDialogDescription>
                                   This action cannot be undone. The note will be removed from your notes.
                                 </AlertDialogDescription>
                               </AlertDialogHeader>
                               <AlertDialogFooter>
                                 <AlertDialogCancel>Cancel</AlertDialogCancel>
                                 <AlertDialogAction onClick={() => requireAdmin(() => { setNotes(prev => prev.filter(n => n.id !== note.id)); toast({ title: "Deleted", description: "Note deleted successfully" }); })}>
                                   Delete
                                 </AlertDialogAction>
                               </AlertDialogFooter>
                             </AlertDialogContent>
                           </AlertDialog>
                         </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
}
