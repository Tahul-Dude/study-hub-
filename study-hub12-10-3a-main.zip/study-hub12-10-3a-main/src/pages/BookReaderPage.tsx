import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowLeft, Edit, BookOpen } from "lucide-react"
import { useNavigate, useParams } from "react-router-dom"
import { useState, useEffect } from "react"
import { mockData, Book } from "@/lib/supabase"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/hooks/useAuth"
import { useLocalStorage } from "@/hooks/useLocalStorage"
import { getAdminId } from "@/lib/utils"

export default function BookReaderPage() {
  const navigate = useNavigate()
  const { id } = useParams()
  const { toast } = useToast()
  const [book, setBook] = useState<Book | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [books] = useLocalStorage<Book[]>('study-hub-books', mockData.books)
  const { user, isAdmin } = useAuth()

  const handleAdminEdit = (bookId: string) => {
    const entered = window.prompt("Admin ID darj karein (Enter Admin ID) :")
    if (!entered) return
    if (!isAdmin) {
      toast({ title: "Access Denied", description: "Sirf Admin edit kar sakta hai.", variant: "destructive" })
      return
    }
    if (entered.trim() !== getAdminId(user?.id || "")) {
      toast({ title: "Galat Admin ID", description: "Sahi Admin ID darj karein.", variant: "destructive" })
      return
    }
    navigate(`/books/${bookId}/edit`)
  }

  useEffect(() => {
    const loadBook = async () => {
      try {
        const foundBook = books.find(b => b.id === id)
        if (foundBook) {
          setBook(foundBook)
        } else {
          toast({
            title: "Book Not Found",
            description: "The requested book could not be found.",
            variant: "destructive"
          })
          navigate("/books")
        }
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to load book.",
          variant: "destructive"
        })
      } finally {
        setIsLoading(false)
      }
    }

    if (id) {
      loadBook()
    }
  }, [id, books, navigate, toast])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="w-8 h-8 animate-pulse mx-auto mb-4" />
          <p>Loading book...</p>
        </div>
      </div>
    )
  }

  if (!book) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p>Book not found</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-primary text-white sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-white hover:bg-white/10"
                onClick={() => navigate("/books")}
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <BookOpen className="w-6 h-6" />
              <div>
                <h1 className="text-xl font-bold">{book.title}</h1>
                <p className="text-white/80 text-sm">by {book.author}</p>
              </div>
            </div>
            <Button 
              variant="secondary" 
              size="sm"
              className="bg-white/10 border-white/20 text-white hover:bg-white/20"
              onClick={() => handleAdminEdit(book.id)}
            >
              <Edit className="w-4 h-4 mr-2" />
              Edit
            </Button>
          </div>
        </div>
      </div>

      {/* Book Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-8">
              {book.pdf_url && (
                <Button variant="outline" className="mb-4" onClick={() => window.open(book.pdf_url!, '_blank')}>
                  Open PDF
                </Button>
              )}
              <div className="prose prose-lg max-w-none">
                {book.content ? (
                  <div className="whitespace-pre-wrap">
                    {book.content}
                  </div>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <BookOpen className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>This book doesn't have content yet.</p>
                      <Button 
                        className="mt-4"
                        onClick={() => handleAdminEdit(book.id)}
                      >
                        Add Content
                      </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}