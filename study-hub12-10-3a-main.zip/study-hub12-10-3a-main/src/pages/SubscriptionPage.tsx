import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Crown, ArrowLeft, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useSubscription } from '@/hooks/useSubscription';
import { SubscriptionPlans } from '@/components/subscription/SubscriptionPlans';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';

export default function SubscriptionPage() {
  const navigate = useNavigate();
  const { subscribed, subscriptionTier, subscriptionEnd, checkSubscription } = useSubscription();
  const { toast } = useToast();
  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = async () => {
    try {
      setRefreshing(true);
      await checkSubscription();
      toast({
        title: "Subscription Status Updated",
        description: "Your subscription status has been refreshed.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to refresh subscription status.",
        variant: "destructive",
      });
    } finally {
      setRefreshing(false);
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-primary text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/home')}
                className="text-white hover:bg-white/20"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
              <div className="border-l border-white/30 pl-4">
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Crown className="w-6 h-6" />
                  Subscription Plans
                </h1>
                <p className="text-white/80 text-sm">Choose the perfect plan for your learning journey</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleRefresh}
              disabled={refreshing}
              className="text-white hover:bg-white/20"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
              Refresh Status
            </Button>
          </div>
        </div>
      </div>

      {/* Current Subscription Status */}
      {subscribed && (
        <div className="container mx-auto px-4 py-6">
          <Card className="bg-success/10 border-success/20">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2 text-success">
                    <Crown className="w-5 h-5" />
                    Premium Active
                  </CardTitle>
                  <CardDescription>
                    You're currently on the <strong>{subscriptionTier}</strong> plan
                  </CardDescription>
                </div>
                <Badge className="bg-success text-success-foreground">
                  Active
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">
                    Your subscription renews on: <strong>{formatDate(subscriptionEnd)}</strong>
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-2">
            Unlock Premium Learning
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Get unlimited access to premium notes, quizzes, and exclusive study materials. 
            Choose the plan that works best for you.
          </p>
        </div>

        {/* Subscription Plans */}
        <SubscriptionPlans />

        {/* Features Comparison */}
        <div className="mt-16">
          <h3 className="text-2xl font-bold text-center mb-8">What's Included</h3>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Free Features</CardTitle>
                <CardDescription>Available to all users</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-sm">• Access to basic study notes</p>
                <p className="text-sm">• Limited quiz attempts (5 per day)</p>
                <p className="text-sm">• Community support</p>
                <p className="text-sm">• Basic progress tracking</p>
              </CardContent>
            </Card>

            <Card className="border-primary/50 bg-primary/5">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Crown className="w-5 h-5 text-primary" />
                  Premium Features
                </CardTitle>
                <CardDescription>Unlock your full potential</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-sm">• <strong>Unlimited</strong> access to all premium notes</p>
                <p className="text-sm">• <strong>Unlimited</strong> quiz attempts</p>
                <p className="text-sm">• Advanced study materials & guides</p>
                <p className="text-sm">• Priority customer support</p>
                <p className="text-sm">• Detailed analytics & insights</p>
                <p className="text-sm">• Download content for offline study</p>
                <p className="text-sm">• Early access to new features</p>
                <p className="text-sm">• Personal study recommendations</p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-16 text-center">
          <h3 className="text-2xl font-bold mb-4">Have Questions?</h3>
          <p className="text-muted-foreground mb-6">
            Need help choosing the right plan? Our team is here to help!
          </p>
          <div className="flex justify-center gap-4">
            <Button variant="outline" onClick={() => navigate('/home')}>
              Continue with Free
            </Button>
            <Button onClick={() => window.open('mailto:support@studyhub.com')}>
              Contact Support
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}