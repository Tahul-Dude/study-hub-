import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, Crown, Home, BookOpen } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useSubscription } from '@/hooks/useSubscription';

export default function SubscriptionSuccessPage() {
  const navigate = useNavigate();
  const { checkSubscription, subscribed, subscriptionTier } = useSubscription();
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const verifySubscription = async () => {
      try {
        // Wait a moment for Stripe to process
        await new Promise(resolve => setTimeout(resolve, 2000));
        await checkSubscription();
      } finally {
        setChecking(false);
      }
    };

    verifySubscription();
  }, [checkSubscription]);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <Card className="max-w-md w-full text-center">
        <CardHeader className="pb-6">
          <div className="mx-auto w-20 h-20 bg-success/10 rounded-full flex items-center justify-center mb-4">
            <CheckCircle className="w-10 h-10 text-success" />
          </div>
          <CardTitle className="text-2xl font-bold flex items-center justify-center gap-2">
            <Crown className="w-6 h-6 text-primary" />
            Welcome to Premium!
          </CardTitle>
          <CardDescription>
            {checking 
              ? "Verifying your subscription..." 
              : subscribed 
                ? `Your ${subscriptionTier} subscription is now active`
                : "Your payment was successful and your subscription is being activated"
            }
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="bg-primary/5 rounded-lg p-4">
            <h3 className="font-semibold mb-2">You now have access to:</h3>
            <ul className="text-sm space-y-1 text-left">
              <li>• Unlimited premium notes</li>
              <li>• Unlimited quiz attempts</li>
              <li>• Advanced study materials</li>
              <li>• Priority support</li>
              <li>• Detailed analytics</li>
              <li>• Offline content downloads</li>
            </ul>
          </div>

          <div className="space-y-3">
            <Button 
              onClick={() => navigate('/home')} 
              className="w-full"
            >
              <Home className="w-4 h-4 mr-2" />
              Go to Dashboard
            </Button>
            
            <Button 
              variant="outline" 
              onClick={() => navigate('/notes')}
              className="w-full"
            >
              <BookOpen className="w-4 h-4 mr-2" />
              Explore Premium Notes
            </Button>
          </div>

          <p className="text-xs text-muted-foreground">
            You can manage your subscription anytime from your account settings.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}