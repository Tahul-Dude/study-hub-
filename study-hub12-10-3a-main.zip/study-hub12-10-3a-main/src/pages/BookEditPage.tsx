import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Save, BookOpen } from "lucide-react"
import { useNavigate, useParams } from "react-router-dom"
import { useState, useEffect } from "react"
import { mockData, Book } from "@/lib/supabase"
import { useToast } from "@/hooks/use-toast"
import { useLocalStorage } from "@/hooks/useLocalStorage"

export default function BookEditPage() {
  const navigate = useNavigate()
  const { id } = useParams()
  const { toast } = useToast()
  const [books, setBooks] = useLocalStorage<Book[]>('study-hub-books', mockData.books)
  const [book, setBook] = useState<Book | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)

  const categories = ["Mathematics", "Math", "Science", "Physics", "Biology", "Chemistry", "Hindi", "English", "History", "Literature", "Technology", "Arts"]

  useEffect(() => {
    const loadBook = () => {
      try {
        const foundBook = books.find((b: Book) => b.id === id)
        if (foundBook) {
          setBook(foundBook)
        } else {
          toast({
            title: "Book Not Found",
            description: "The requested book could not be found.",
            variant: "destructive"
          })
          navigate("/books")
        }
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to load book.",
          variant: "destructive"
        })
      } finally {
        setIsLoading(false)
      }
    }

    if (id) {
      loadBook()
    }
  }, [id, books, navigate, toast])

  const handleSave = async () => {
    if (!book) return

    if (!book.title || !book.author || !book.category) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields.",
        variant: "destructive"
      })
      return
    }

    setIsSaving(true)
    try {
      const updatedBooks = books.map((b: Book) => 
        b.id === book.id 
          ? { ...book, content: book.content || "", updated_at: new Date().toISOString().split('T')[0] }
          : b
      )
      setBooks(updatedBooks)

      toast({
        title: "Success",
        description: "Book updated successfully!",
        variant: "success"
      })

      navigate(`/books/${book.id}/read`)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save book.",
        variant: "destructive"
      })
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="w-8 h-8 animate-pulse mx-auto mb-4" />
          <p>Loading book...</p>
        </div>
      </div>
    )
  }

  if (!book) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p>Book not found</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-primary text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-white hover:bg-white/10"
                onClick={() => navigate("/books")}
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <BookOpen className="w-6 h-6" />
              <div>
                <h1 className="text-2xl font-bold">Edit Book</h1>
                <p className="text-white/80 text-sm">Make changes to your book</p>
              </div>
            </div>
            <Button 
              variant="secondary"
              onClick={handleSave}
              disabled={isSaving}
              className="bg-white text-primary hover:bg-white/90"
            >
              <Save className="w-4 h-4 mr-2" />
              {isSaving ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </div>
      </div>

      {/* Edit Form */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Book Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">Title *</Label>
                  <Input
                    id="title"
                    value={book.title}
                    onChange={(e) => setBook({ ...book, title: e.target.value })}
                    placeholder="Enter book title"
                  />
                </div>
                <div>
                  <Label htmlFor="author">Author *</Label>
                  <Input
                    id="author"
                    value={book.author}
                    onChange={(e) => setBook({ ...book, author: e.target.value })}
                    placeholder="Enter author name"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">Category *</Label>
                  <Select 
                    value={book.category} 
                    onValueChange={(value) => setBook({ ...book, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="pages">Number of Pages</Label>
                  <Input
                    id="pages"
                    type="number"
                    value={book.pages}
                    onChange={(e) => setBook({ ...book, pages: parseInt(e.target.value) || 0 })}
                    placeholder="Enter page count"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={book.description}
                  onChange={(e) => setBook({ ...book, description: e.target.value })}
                  placeholder="Enter book description"
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="content">Book Content</Label>
                <Textarea
                  id="content"
                  value={book.content || ""}
                  onChange={(e) => setBook({ ...book, content: e.target.value })}
                  placeholder="Enter the book content here..."
                  rows={12}
                  className="font-mono text-sm"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  You can use markdown formatting for better text structure.
                </p>
              </div>

              <div className="flex gap-4">
                <Button 
                  onClick={handleSave}
                  disabled={isSaving}
                  className="flex-1"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {isSaving ? "Saving..." : "Save Changes"}
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => navigate(`/books/${book.id}/read`)}
                  className="flex-1"
                >
                  Preview
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}