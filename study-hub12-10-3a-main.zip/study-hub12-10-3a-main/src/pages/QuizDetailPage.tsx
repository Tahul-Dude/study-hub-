import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Clock, Target, Trophy, Play } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { mockData, Quiz } from "@/lib/supabase";

interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
}

interface QuizDetail {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: "Easy" | "Medium" | "Hard";
  questions: Question[];
  duration: number;
  averageScore: number;
  completions: number;
}

export default function QuizDetailPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [quizzes] = useLocalStorage<Quiz[]>('study-hub-quizzes', mockData.quizzes);

  // Find the actual quiz by id
  const quiz = quizzes.find(q => q.id === id);

  if (!quiz) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Quiz not found</h1>
          <Button onClick={() => navigate('/quiz')}>Back to Quizzes</Button>
        </div>
      </div>
    );
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy": return "bg-study-green";
      case "Medium": return "bg-study-orange";
      case "Hard": return "bg-study-purple";
      default: return "bg-gray-500";
    }
  };

  const startQuiz = () => {
    // Navigate to quiz taking page
    navigate(`/quiz/${id}/take`);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-accent text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center space-x-3">
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-white hover:bg-white/10"
              onClick={() => navigate("/quiz")}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">{quiz.title}</h1>
              <p className="text-white/80 text-sm">{quiz.category}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quiz Details */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card className="mb-6">
            <CardHeader>
              <div className="flex justify-between items-start">
                <CardTitle className="text-2xl">{quiz.title}</CardTitle>
                <Badge className={`text-white ${getDifficultyColor(quiz.difficulty)}`}>
                  {quiz.difficulty}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-6">{quiz.description}</p>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <Target className="w-6 h-6 mx-auto mb-2 text-study-blue" />
                  <div className="font-semibold">{quiz.questions.length}</div>
                  <div className="text-sm text-muted-foreground">Questions</div>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <Clock className="w-6 h-6 mx-auto mb-2 text-study-green" />
                  <div className="font-semibold">{quiz.duration} mins</div>
                  <div className="text-sm text-muted-foreground">Duration</div>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <Trophy className="w-6 h-6 mx-auto mb-2 text-study-orange" />
                  <div className="font-semibold">New</div>
                  <div className="text-sm text-muted-foreground">Status</div>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <Play className="w-6 h-6 mx-auto mb-2 text-study-purple" />
                  <div className="font-semibold">0</div>
                  <div className="text-sm text-muted-foreground">Taken</div>
                </div>
              </div>

              <Button 
                onClick={startQuiz}
                className="w-full md:w-auto bg-study-purple hover:bg-study-purple/90 text-white px-8 py-3 text-lg"
              >
                <Play className="w-5 h-5 mr-2" />
                Start Quiz
              </Button>
            </CardContent>
          </Card>

          {/* Instructions */}
          <Card>
            <CardHeader>
              <CardTitle>Instructions</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-muted-foreground">
                <li>• Read each question carefully before selecting your answer</li>
                <li>• You can navigate between questions using the navigation buttons</li>
                <li>• Your quiz will be automatically submitted when time runs out</li>
                <li>• Make sure you have a stable internet connection</li>
                <li>• You can review your answers before final submission</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}