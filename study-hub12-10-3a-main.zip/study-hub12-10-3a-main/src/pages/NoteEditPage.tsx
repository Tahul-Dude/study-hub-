import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Save } from "lucide-react";
import { useState } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { mockData, Note } from "@/lib/supabase";

export default function NoteEditPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [notes, setNotes] = useLocalStorage<Note[]>('study-hub-notes', mockData.notes);
  
  const note = notes.find(n => n.id === id);
  const [editNote, setEditNote] = useState({
    title: note?.title || "",
    pdf_url: note?.pdf_url || "",
    category: note?.category || "",
    level: note?.level || "",
    tags: note?.tags.join(', ') || ""
  });

  const categories = ["Maths", "Physics", "Chemistry", "Biology", "Botany", "Science", "Hindi", "English", "Arts", "General GK", "Reasoning", "History", "Geography"]; 
  const levels = ["Class 11", "Class 12", "Graduate"];

  if (!note) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Note not found</h1>
          <Button onClick={() => navigate('/notes')}>Back to Notes</Button>
        </div>
      </div>
    );
  }

  const handleSave = () => {
    if (!editNote.title || !editNote.category || !editNote.pdf_url) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    const updatedNote: Note = {
      ...note,
      title: editNote.title,
      category: editNote.category,
      level: (editNote.level as Note['level']) || undefined,
      tags: editNote.tags.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0),
      pdf_url: editNote.pdf_url,
      updated_at: new Date().toISOString().split('T')[0]
    };

    const updatedNotes = notes.map(n => n.id === note.id ? updatedNote : n);
    setNotes(updatedNotes);
    
    toast({
      title: "Success",
      description: "Note updated successfully!",
      variant: "success"
    });
    
    navigate(`/notes/${note.id}/view`);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-secondary text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Link to={`/notes/${note.id}/view`}>
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold">Edit Note</h1>
                <p className="text-white/80 text-sm">Update your study note</p>
              </div>
            </div>
            <Button 
              variant="secondary" 
              className="bg-white text-study-green hover:bg-white/90"
              onClick={handleSave}
            >
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </div>
      </div>

      {/* Edit Form */}
      <div className="container mx-auto px-4 py-6">
        <Card>
          <CardHeader>
            <CardTitle>Edit Note</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={editNote.title}
                onChange={(e) => setEditNote({ ...editNote, title: e.target.value })}
                placeholder="Enter note title"
              />
            </div>
            
            <div>
              <Label htmlFor="category">Category</Label>
              <Select value={editNote.category} onValueChange={(value) => setEditNote({ ...editNote, category: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {editNote.category && (
              <div>
                <Label htmlFor="level">Level</Label>
                <Select value={editNote.level} onValueChange={(value) => setEditNote({ ...editNote, level: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select level" />
                  </SelectTrigger>
                  <SelectContent>
                    {levels.map((lvl) => (
                      <SelectItem key={lvl} value={lvl}>
                        {lvl}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            
            <div>
              <Label htmlFor="tags">Tags (comma separated)</Label>
              <Input
                id="tags"
                value={editNote.tags}
                onChange={(e) => setEditNote({ ...editNote, tags: e.target.value })}
                placeholder="physics, equations, important"
              />
            </div>
            
            <div>
              <Label htmlFor="pdf_url">PDF URL</Label>
              <Input
                id="pdf_url"
                value={editNote.pdf_url}
                onChange={(e) => setEditNote({ ...editNote, pdf_url: e.target.value })}
                placeholder="https://example.com/your-note.pdf"
              />
              <p className="text-sm text-muted-foreground mt-1">Paste a public PDF link to embed in the note.</p>
            </div>
            
            <div className="flex gap-4">
              <Button onClick={handleSave} className="flex-1">
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => navigate(`/notes/${note.id}/view`)}
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}