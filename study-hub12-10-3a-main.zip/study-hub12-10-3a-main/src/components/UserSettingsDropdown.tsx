import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";

import { User, Settings, LogOut, Shield, Copy, Key, UserMinus, Menu, Home, Share2, Star, Heart, ShoppingCart, MessageCircle, Mail, Smartphone } from "lucide-react";
import { ThemeToggle } from "@/components/theme/ThemeToggle";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { getAdminId } from "@/lib/utils";
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
export function UserSettingsDropdown() {
  const { user, isAdmin, signOut } = useAuth();
  const navigate = useNavigate();
  const adminId = user?.id ? getAdminId(user.id) : "";
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [shareMenuOpen, setShareMenuOpen] = useState(false);
  
  // Account settings form state
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    dob: '',
  });
  const [isLoading, setIsLoading] = useState(false);

  // App quick actions state
  const [ratingOpen, setRatingOpen] = useState(false);
  const [appRating, setAppRating] = useState<number>(() => {
    try {
      const v = parseInt(localStorage.getItem('app-rating') || '0', 10);
      return isNaN(v) ? 0 : v;
    } catch {
      return 0;
    }
  });
  const [followed, setFollowed] = useState<boolean>(() => localStorage.getItem('app-followed') === 'true');
  const [purchaseCount, setPurchaseCount] = useState<number>(() => {
    const v = parseInt(localStorage.getItem('purchase-count') || '0', 10);
    return isNaN(v) ? 0 : v;
  });

  useEffect(() => {
    const update = () => {
      const v = parseInt(localStorage.getItem('purchase-count') || '0', 10);
      setPurchaseCount(isNaN(v) ? 0 : v);
    };
    window.addEventListener('purchase-count-updated', update as EventListener);
    return () => window.removeEventListener('purchase-count-updated', update as EventListener);
  }, []);

  // Initialize form data when settings dialog opens
  useEffect(() => {
    if (settingsOpen && user) {
      setFormData({
        name: (user.user_metadata?.full_name as string) || '',
        phone: (user.phone as string) || (user.user_metadata?.phone as string) || '',
        dob: (user.user_metadata?.dob as string) || '',
      });
    }
  }, [settingsOpen, user]);

  const handleCopyUserId = () => {
    if (user?.id) {
      navigator.clipboard.writeText(user.id);
      toast.success("User ID copied to clipboard");
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate("/auth");
      toast.success("Signed out successfully");
    } catch (error) {
      toast.error("Failed to sign out");
    }
  };

  const handleCreateAdminId = async () => {
    if (!adminId) return;
    try {
      await navigator.clipboard.writeText(adminId);
      toast.success("Admin ID copied. Share with owner to grant admin access.");
    } catch {
      try {
        const el = document.createElement("textarea");
        el.value = adminId;
        el.style.position = "fixed";
        el.style.left = "-9999px";
        document.body.appendChild(el);
        el.select();
        const ok = document.execCommand("copy");
        document.body.removeChild(el);
        if (ok) {
          toast.success("Admin ID copied (fallback).");
        } else {
          throw new Error("Copy failed");
        }
      } catch {
        toast.error("Could not copy. Your Admin ID is shown under the menu.");
      }
    }
  };

  const handleCreateAdminRole = async () => {
    if (!user?.id) return;

    const confirmed = window.confirm(
      "No admin found yet? Create Admin role for this account. Proceed?"
    );
    if (!confirmed) return;

    try {
      const result = await toast.promise(
        (async () => {
          console.log("Starting admin role creation for user:", user.id);
          
          // First, check if profiles table exists and if there are any admins
          const { count, error: countError } = await supabase
            .from("profiles")
            .select("user_id", { count: "exact", head: true })
            .eq("role", "admin");

          console.log("Admin count check result:", { count, countError });

          if (countError) {
            console.error("Error checking admin count:", countError);
            // If table doesn't exist, we'll still try to create the admin
            if (countError.code === 'PGRST116' || countError.message?.includes('relation "public.profiles" does not exist')) {
              console.log("Profiles table might not exist, proceeding with admin creation");
            } else {
              throw countError;
            }
          } else if ((count ?? 0) > 0) {
            throw new Error("An admin already exists. Please contact the admin.");
          }

          // Create/update the admin role
          const { error, data } = await supabase
            .from("profiles")
            .upsert(
              { user_id: user.id, role: "admin" }, 
              { onConflict: "user_id", ignoreDuplicates: false }
            );

          console.log("Admin creation result:", { error, data });

          if (error) {
            console.error("Error creating admin:", error);
            throw error;
          }

          return data;
        })(),
        {
          loading: "Checking and creating admin...",
          success: "Admin role created successfully!",
          error: (e) => {
            console.error("Admin creation failed:", e);
            return typeof e === "string" ? e : e?.message || "Failed to create admin role. Please try again.";
          },
        }
      );

      console.log("Admin creation completed:", result);
      
      // Add a small delay before reload to ensure the toast is visible
      setTimeout(() => {
        window.location.reload();
      }, 1500);
      
    } catch (error) {
      console.error("Outer catch - Admin creation error:", error);
      toast.error("Something went wrong. Please check the console for details.");
    }
  };

  const handleResetAdmin = async () => {
    if (!user?.id) return;
    const confirmText = window.prompt(
      "Type RESET to remove existing admin and make your account Admin. This cannot be undone."
    );
    if (confirmText !== "RESET") return;

    try {
      const { error: demoteErr } = await supabase
        .from("profiles")
        .update({ role: "user" })
        .eq("role", "admin");
      if (demoteErr) throw demoteErr;

      const { error: promoteErr } = await supabase
        .from("profiles")
        .upsert({ user_id: user.id, role: "admin" }, { onConflict: "user_id" });
      if (promoteErr) throw promoteErr;

      toast.success("Admin reset complete. You are now Admin.");
      window.location.reload();
    } catch (e) {
      toast.error("Failed to reset admin. Please try again.");
    }
  };

  // Quick actions
  const handleShareApp = () => {
    setShareMenuOpen(true);
  };

  const shareToApp = (platform: string) => {
    const url = window.location.origin;
    const title = 'Study Hub - Your Learning Companion';
    const text = 'Check out this amazing study app! Perfect for managing books, notes, and quizzes.';
    
    let shareUrl = '';
    
    switch (platform) {
      case 'whatsapp':
        shareUrl = `https://wa.me/?text=${encodeURIComponent(`${title}\n${text}\n${url}`)}`;
        break;
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
        break;
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(`${title}\n${text}`)}&url=${encodeURIComponent(url)}`;
        break;
      case 'telegram':
        shareUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(`${title}\n${text}`)}`;
        break;
      case 'email':
        shareUrl = `mailto:?subject=${encodeURIComponent(title)}&body=${encodeURIComponent(`${text}\n\n${url}`)}`;
        break;
      case 'sms':
        shareUrl = `sms:?body=${encodeURIComponent(`${title}\n${text}\n${url}`)}`;
        break;
      case 'copy':
        navigator.clipboard.writeText(url).then(() => {
          toast.success('App link copied! 📋');
        }).catch(() => {
          toast.error('Failed to copy link');
        });
        setShareMenuOpen(false);
        return;
    }
    
    if (shareUrl) {
      window.open(shareUrl, '_blank');
      toast.success(`Opening ${platform}... 🚀`);
      setShareMenuOpen(false);
    }
  };

  const handleToggleFollow = () => {
    try {
      const next = !followed;
      setFollowed(next);
      localStorage.setItem('app-followed', String(next));
      
      if (next) {
        toast.success('💖 Following Study Hub! You\'ll get updates about new features');
      } else {
        toast.success('👋 Unfollowed Study Hub');
      }
    } catch (error) {
      toast.error('Failed to update follow status');
    }
  };

  const handleSubmitRating = () => {
    localStorage.setItem('app-rating', String(appRating));
    toast.success('Thanks for rating!');
    setRatingOpen(false);
  };

  const handleUpdateProfile = async () => {
    if (!user?.id) return;
    
    setIsLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({
        data: {
          full_name: formData.name,
          phone: formData.phone,
          dob: formData.dob,
        }
      });

      if (error) throw error;
      
      toast.success('Profile updated successfully!');
      setSettingsOpen(false);
    } catch (error: any) {
      toast.error('Failed to update profile: ' + (error.message || 'Unknown error'));
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) return null;
  
  
  return (<>
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="ghost" 
          className="relative h-12 w-12 rounded-full border-2 border-black dark:border-white bg-transparent hover:bg-black/10 dark:hover:bg-white/10 transition-all duration-300 shadow-[0_0_0_2px_transparent,0_0_0_4px_black] dark:shadow-[0_0_0_2px_transparent,0_0_0_4px_white]" 
          aria-label="Open menu"
        >
          <Menu className="h-5 w-5 text-black dark:text-white" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-64" align="end" forceMount>
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium leading-none">User Account</p>
            <p className="text-xs leading-none text-muted-foreground">
              {user.email}
            </p>
            {isAdmin && (
              <div className="flex items-center gap-1 mt-1">
                <Shield className="h-3 w-3 text-blue-500" />
                <span className="text-xs text-blue-500 font-medium">Admin</span>
              </div>
            )}
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />

        <DropdownMenuItem onClick={() => navigate('/home')} className="cursor-pointer">
          <Home className="mr-2 h-4 w-4" />
          <span>Home</span>
        </DropdownMenuItem>

        <DropdownMenuItem onClick={handleShareApp} className="cursor-pointer">
          <Share2 className="mr-2 h-4 w-4" />
          <span>Share App</span>
        </DropdownMenuItem>

        <DropdownMenuItem onClick={() => setRatingOpen(true)} className="cursor-pointer">
          <Star className="mr-2 h-4 w-4" />
          <span>Rate App {appRating ? `(${appRating}/5)` : ''}</span>
        </DropdownMenuItem>

        <DropdownMenuItem onClick={handleToggleFollow} className="cursor-pointer">
          <Heart className={`mr-2 h-4 w-4 ${followed ? 'text-red-500 fill-red-500' : ''}`} />
          <span>{followed ? 'Unfollow' : 'Follow'}</span>
        </DropdownMenuItem>

        <DropdownMenuItem className="cursor-default">
          <ShoppingCart className="mr-2 h-4 w-4" />
          <span>Purchases: {purchaseCount}</span>
        </DropdownMenuItem>

        <DropdownMenuSeparator />
        
        <DropdownMenuItem onClick={handleCopyUserId} className="cursor-pointer">
          <Copy className="mr-2 h-4 w-4" />
          <div className="flex flex-col">
            <span>Copy User ID</span>
            <span className="text-xs text-muted-foreground truncate">
              {user.id}
            </span>
          </div>
        </DropdownMenuItem>

        <DropdownMenuItem onClick={handleCreateAdminId} className="cursor-pointer">
          <Key className="mr-2 h-4 w-4" />
          <div className="flex flex-col">
            <span>Copy Admin ID</span>
            <span className="text-xs text-muted-foreground">Share this ID with the owner to get admin role</span>
            <span className="text-xs text-muted-foreground truncate">{adminId}</span>
          </div>
        </DropdownMenuItem>

        {!isAdmin && (
          <>
            <DropdownMenuItem onClick={handleCreateAdminRole} className="cursor-pointer">
              <Shield className="mr-2 h-4 w-4" />
              <div className="flex flex-col">
                <span>Create Admin ID</span>
                <span className="text-xs text-muted-foreground">First-time setup: make this account admin</span>
              </div>
            </DropdownMenuItem>

            <DropdownMenuItem onClick={handleResetAdmin} className="cursor-pointer text-red-600 focus:text-red-600">
              <UserMinus className="mr-2 h-4 w-4" />
              <div className="flex flex-col">
                <span>Reset Admin (Replace existing)</span>
                <span className="text-xs text-muted-foreground">Remove old admin and make your account Admin</span>
              </div>
            </DropdownMenuItem>
          </>
        )}

        <DropdownMenuItem onClick={() => setSettingsOpen(true)} className="cursor-pointer">
          <User className="mr-2 h-4 w-4" />
          <span>Account Settings</span>
        </DropdownMenuItem>

        <DropdownMenuItem asChild>
          <div className="flex items-center px-2 py-1.5 cursor-default">
            <Settings className="mr-2 h-4 w-4" />
            <span className="mr-2">Theme</span>
            <ThemeToggle />
          </div>
        </DropdownMenuItem>
        {isAdmin && (
          <DropdownMenuItem className="cursor-pointer">
            <Shield className="mr-2 h-4 w-4" />
            <span>Admin Panel</span>
          </DropdownMenuItem>
        )}

        <DropdownMenuSeparator />
        
        <DropdownMenuItem onClick={handleSignOut} className="cursor-pointer text-red-600 focus:text-red-600">
          <LogOut className="mr-2 h-4 w-4" />
          <span>Sign Out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
    <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Account Settings</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>User ID</Label>
            <Input readOnly value={user.id} className="bg-muted" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input 
              id="name"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Enter your full name"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone Number</Label>
            <Input 
              id="phone"
              value={formData.phone}
              onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
              placeholder="Enter your phone number"
            />
          </div>
          <div className="space-y-2">
            <Label>Email</Label>
            <Input readOnly value={user.email || "Not set"} className="bg-muted" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="dob">Date of Birth</Label>
            <Input 
              id="dob"
              type="date"
              value={formData.dob}
              onChange={(e) => setFormData(prev => ({ ...prev, dob: e.target.value }))}
            />
          </div>
          <div className="flex gap-2 pt-4">
            <Button onClick={handleUpdateProfile} disabled={isLoading} className="flex-1">
              {isLoading ? 'Saving...' : 'Save Changes'}
            </Button>
            <Button variant="outline" onClick={() => setSettingsOpen(false)} className="flex-1">
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
    
    <Dialog open={shareMenuOpen} onOpenChange={setShareMenuOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Share Study Hub</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <Button 
            variant="outline" 
            onClick={() => shareToApp('whatsapp')}
            className="flex items-center gap-2 h-12"
          >
            <MessageCircle className="h-5 w-5 text-green-600" />
            WhatsApp
          </Button>
          
          <Button 
            variant="outline" 
            onClick={() => shareToApp('facebook')}
            className="flex items-center gap-2 h-12"
          >
            <Share2 className="h-5 w-5 text-blue-600" />
            Facebook
          </Button>
          
          <Button 
            variant="outline" 
            onClick={() => shareToApp('twitter')}
            className="flex items-center gap-2 h-12"
          >
            <MessageCircle className="h-5 w-5 text-blue-400" />
            Twitter
          </Button>
          
          <Button 
            variant="outline" 
            onClick={() => shareToApp('telegram')}
            className="flex items-center gap-2 h-12"
          >
            <MessageCircle className="h-5 w-5 text-blue-500" />
            Telegram
          </Button>
          
          <Button 
            variant="outline" 
            onClick={() => shareToApp('email')}
            className="flex items-center gap-2 h-12"
          >
            <Mail className="h-5 w-5 text-gray-600" />
            Email
          </Button>
          
          <Button 
            variant="outline" 
            onClick={() => shareToApp('sms')}
            className="flex items-center gap-2 h-12"
          >
            <Smartphone className="h-5 w-5 text-green-500" />
            SMS
          </Button>
          
          <Button 
            variant="outline" 
            onClick={() => shareToApp('copy')}
            className="flex items-center gap-2 h-12 col-span-2"
          >
            <Copy className="h-5 w-5 text-orange-500" />
            Copy Link
          </Button>
        </div>
      </DialogContent>
    </Dialog>
    <Dialog open={ratingOpen} onOpenChange={setRatingOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Rate the App</DialogTitle>
        </DialogHeader>
        <div className="flex items-center gap-2 justify-center py-2">
          {[1,2,3,4,5].map((n) => (
            <button key={n} onClick={() => setAppRating(n)} aria-label={`${n} star`} className="p-1">
              <Star className={`w-6 h-6 ${n <= appRating ? 'text-yellow-500 fill-yellow-500' : 'text-muted-foreground'}`} />
            </button>
          ))}
        </div>
        <Button onClick={handleSubmitRating} className="w-full">Submit</Button>
      </DialogContent>
    </Dialog>
  </> );
}