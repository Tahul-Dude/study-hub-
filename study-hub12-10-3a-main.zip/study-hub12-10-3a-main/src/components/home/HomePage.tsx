import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, FileText, Brain, Crown } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { UserSettingsDropdown } from "@/components/UserSettingsDropdown";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSubscription } from "@/hooks/useSubscription";

export default function HomePage() {
  const navigate = useNavigate();
  const { subscribed, subscriptionTier } = useSubscription();
  const menuItems = [
    {
      title: "Books",
      description: "Browse our collection of educational books",
      icon: BookOpen,
      color: "bg-study-blue",
      gradient: "bg-gradient-primary",
      href: "/books"
    },
    {
      title: "Notes",
      description: "Access study notes by class and subject",
      icon: FileText,
      color: "bg-study-green", 
      gradient: "bg-gradient-secondary",
      href: "/notes"
    },
    {
      title: "Quiz",
      description: "Test your knowledge with interactive quizzes",
      icon: Brain,
      color: "bg-study-purple",
      gradient: "bg-gradient-accent", 
      href: "/quiz"
    }
  ];

  const [counts, setCounts] = useState({ books: 0, notes: 0, quizzes: 0, learners: 0 });
  const [loadingCounts, setLoadingCounts] = useState(true);

  useEffect(() => {
    let isMounted = true;
    async function fetchCounts() {
      try {
        const [booksRes, notesRes, quizzesRes, profilesRes] = await Promise.all([
          supabase.from('books').select('*', { count: 'exact', head: true }),
          supabase.from('notes').select('*', { count: 'exact', head: true }),
          supabase.from('quizzes').select('*', { count: 'exact', head: true }),
          supabase.from('profiles').select('*', { count: 'exact', head: true }),
        ]);
        if (isMounted) {
          setCounts({
            books: booksRes.count ?? 0,
            notes: notesRes.count ?? 0,
            quizzes: quizzesRes.count ?? 0,
            learners: profilesRes.count ?? 0,
          });
        }
      } finally {
        if (isMounted) setLoadingCounts(false);
      }
    }
    fetchCounts();
    return () => { isMounted = false; };
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-primary text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <BookOpen className="w-8 h-8" />
              <div>
                <h1 className="text-2xl font-bold">Study Hub</h1>
                <div className="flex items-center gap-2">
                  <p className="text-white/80 text-sm">Welcome back, Student!</p>
                  {subscribed && (
                    <Badge className="bg-white/20 text-white text-xs">
                      <Crown className="w-3 h-3 mr-1" />
                      {subscriptionTier}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {!subscribed && (
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => navigate('/subscription')}
                  className="bg-white/20 text-white hover:bg-white/30"
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Upgrade to Premium
                </Button>
              )}
              <UserSettingsDropdown />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-2">
            What would you like to study today?
          </h2>
          <p className="text-muted-foreground">
            Choose from our comprehensive learning resources
          </p>
        </div>

        {/* Menu Cards */}
        <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {menuItems.map((item, index) => (
            <Card 
              key={index}
              className="group cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-large border-0 overflow-hidden"
              onClick={() => navigate(item.href)}
            >
              <CardContent className="p-0">
                <div className={`${item.gradient} p-6 text-white text-center`}>
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-full mb-4 group-hover:scale-110 transition-transform duration-300">
                    <item.icon className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-white/90 text-sm">{item.description}</p>
                </div>
                <div className="p-4 bg-white">
                  <Button 
                    variant="ghost" 
                    className="w-full text-gray-600 hover:text-gray-800"
                  >
                    Explore {item.title} →
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Stats Section - dynamic */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-card rounded-lg shadow-soft">
            <div className="text-2xl font-bold text-study-blue" aria-live="polite">{loadingCounts ? '—' : counts.books}</div>
            <div className="text-sm text-muted-foreground">Books Available</div>
          </div>
          <div className="text-center p-4 bg-card rounded-lg shadow-soft">
            <div className="text-2xl font-bold text-study-green" aria-live="polite">{loadingCounts ? '—' : counts.notes}</div>
            <div className="text-sm text-muted-foreground">Study Notes</div>
          </div>
          <div className="text-center p-4 bg-card rounded-lg shadow-soft">
            <div className="text-2xl font-bold text-study-purple" aria-live="polite">{loadingCounts ? '—' : counts.quizzes}</div>
            <div className="text-sm text-muted-foreground">Quizzes</div>
          </div>
          <div className="text-center p-4 bg-card rounded-lg shadow-soft">
            <div className="text-2xl font-bold text-study-orange" aria-live="polite">{loadingCounts ? '—' : counts.learners}</div>
            <div className="text-sm text-muted-foreground">Active Learners</div>
          </div>
        </div>

      </div>
    </div>
  );
}