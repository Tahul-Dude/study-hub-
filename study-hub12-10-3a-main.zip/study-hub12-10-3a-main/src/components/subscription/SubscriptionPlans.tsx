import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Check, Crown, Zap } from 'lucide-react';
import { useSubscription } from '@/hooks/useSubscription';
import { useToast } from '@/hooks/use-toast';

const plans = [
  {
    id: 'free',
    name: 'Free',
    price: '₹0',
    period: 'forever',
    description: 'Perfect for getting started',
    features: [
      'Access to basic notes',
      'Limited quiz attempts',
      'Community support',
      'Basic study materials'
    ],
    icon: Zap,
    color: 'bg-muted',
    textColor: 'text-muted-foreground'
  },
  {
    id: 'monthly',
    name: 'Premium Monthly',
    price: '₹299',
    period: 'per month',
    description: 'Full access to all premium content',
    features: [
      'Unlimited premium notes',
      'Unlimited quiz attempts',
      'Advanced study materials',
      'Priority support',
      'Detailed analytics',
      'Download offline content'
    ],
    icon: Crown,
    color: 'bg-gradient-primary',
    textColor: 'text-white',
    popular: false
  },
  {
    id: 'yearly',
    name: 'Premium Yearly',
    price: '₹2,999',
    period: 'per year',
    originalPrice: '₹3,588',
    description: 'Best value - Save 17%!',
    features: [
      'Everything in Monthly',
      'Save ₹589 annually',
      'Exclusive yearly content',
      'Early access to new features',
      'Personal study consultant',
      'Advanced progress tracking'
    ],
    icon: Crown,
    color: 'bg-gradient-accent',
    textColor: 'text-white',
    popular: true
  }
];

export function SubscriptionPlans() {
  const { subscribed, subscriptionTier, createCheckout, openCustomerPortal } = useSubscription();
  const { toast } = useToast();
  const [loading, setLoading] = useState<string | null>(null);

  const handleSubscribe = async (planId: string) => {
    if (planId === 'free') return;
    
    try {
      setLoading(planId);
      const url = await createCheckout(planId as 'monthly' | 'yearly');
      window.open(url, '_blank');
    } catch (error) {
      console.error('Error creating checkout:', error);
      toast({
        title: "Error",
        description: "Failed to create checkout session. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(null);
    }
  };

  const handleManageSubscription = async () => {
    try {
      setLoading('manage');
      const url = await openCustomerPortal();
      window.open(url, '_blank');
    } catch (error) {
      console.error('Error opening customer portal:', error);
      toast({
        title: "Error",
        description: "Failed to open subscription management. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(null);
    }
  };

  const isCurrentPlan = (planId: string) => {
    if (planId === 'free') return !subscribed;
    if (planId === 'monthly') return subscribed && subscriptionTier === 'Monthly';
    if (planId === 'yearly') return subscribed && subscriptionTier === 'Yearly';
    return false;
  };

  return (
    <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
      {plans.map((plan) => (
        <Card 
          key={plan.id}
          className={`relative transition-all duration-300 hover:scale-105 border-2 ${
            isCurrentPlan(plan.id) 
              ? 'border-primary shadow-large' 
              : plan.popular 
                ? 'border-accent shadow-medium' 
                : 'border-border hover:border-primary/50'
          }`}
        >
          {plan.popular && (
            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
              <Badge className="bg-accent text-accent-foreground px-3 py-1">
                Most Popular
              </Badge>
            </div>
          )}
          
          {isCurrentPlan(plan.id) && (
            <div className="absolute -top-3 right-4">
              <Badge className="bg-success text-success-foreground px-3 py-1">
                Current Plan
              </Badge>
            </div>
          )}

          <CardHeader className="text-center pb-6">
            <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full mb-4 mx-auto ${plan.color}`}>
              <plan.icon className={`w-8 h-8 ${plan.textColor}`} />
            </div>
            <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
            <CardDescription className="text-base">{plan.description}</CardDescription>
            <div className="mt-4">
              <div className="flex items-baseline justify-center gap-2">
                <span className="text-4xl font-bold text-foreground">{plan.price}</span>
                <span className="text-muted-foreground">/{plan.period}</span>
              </div>
              {plan.originalPrice && (
                <div className="text-sm text-muted-foreground mt-1">
                  <span className="line-through">{plan.originalPrice}</span>
                  <span className="ml-2 text-success font-semibold">Save ₹589!</span>
                </div>
              )}
            </div>
          </CardHeader>

          <CardContent className="space-y-4">
            <ul className="space-y-3">
              {plan.features.map((feature, index) => (
                <li key={index} className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-muted-foreground">{feature}</span>
                </li>
              ))}
            </ul>

            <div className="pt-4">
              {isCurrentPlan(plan.id) ? (
                subscribed ? (
                  <Button 
                    variant="outline" 
                    className="w-full" 
                    onClick={handleManageSubscription}
                    disabled={loading === 'manage'}
                  >
                    {loading === 'manage' ? 'Opening...' : 'Manage Subscription'}
                  </Button>
                ) : (
                  <Button variant="outline" className="w-full" disabled>
                    Current Plan
                  </Button>
                )
              ) : (
                <Button 
                  className={`w-full ${
                    plan.popular 
                      ? 'bg-accent hover:bg-accent/90' 
                      : plan.id === 'free' 
                        ? 'variant-outline' 
                        : ''
                  }`}
                  variant={plan.id === 'free' ? 'outline' : 'default'}
                  onClick={() => handleSubscribe(plan.id)}
                  disabled={loading === plan.id || plan.id === 'free'}
                >
                  {loading === plan.id 
                    ? 'Processing...' 
                    : plan.id === 'free' 
                      ? 'Current Plan'
                      : 'Upgrade Now'
                  }
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}